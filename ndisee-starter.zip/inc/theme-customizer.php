<?php

/**
 * ndisee-starter customizer
 *
 * @package ndisee-starter
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


add_action(
    'init',
    function () {

        if (class_exists('kirki')) {

            /**
             * Added Panels & Sections
             */

            //Add panel
            new \Kirki\Panel(
                'ndisee_starter_customizer',
                [
                    'priority'    => 10,
                    'title'       => esc_html__('Ndisee Starter Customizer', 'ndisee-starter'),
                ]
            );



            /**
             * Customizer Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'ndisee_starter_general_settngs',
                [
                    'title'       => esc_html__('General Settings', 'ndisee-starter'),
                    'description' => esc_html__('', 'ndisee-starter'),
                    'panel'       => 'ndisee_starter_customizer',
                    'priority'    => 10,
                ]
            );



            //Add panel
            new \Kirki\Panel(
                    'ndisee_starter__front_page_customizer',
                    [
                        'priority'    => 10,
                        'title'       => esc_html__('Front Page', 'ndisee-starter'),
                    ]
            );


            /**
             * Customizer Section
             */
            //=========== Hero section ================ //
            new \Kirki\Section(
                    'ndisee_starter_front_page_settngs',
                    [
                        'title'       => esc_html__('Hero Section', 'ndisee-starter'),
                        'description' => esc_html__('', 'ndisee-starter'),
                        'panel'       => 'ndisee_starter__front_page_customizer',
                        'priority'    => 10,
                    ]
            );


            // Front Page Hero Section

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_hero_title',
                    'label'       => esc_html__('Hero Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Hero Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => esc_html__('Advanced Prosthetic Solutions, Empowering Mobility Every Day', 'ndisee-starter'),
                ]
            );

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_hero_subtitle',
                    'label'       => esc_html__('Hero Sub Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Hero Sub Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => ndisee_starter_kses('  With our team of dedicated experts and state-of-the-art technology <br> to help you regain your independence and rediscover your capabilities. ', 'ndisee-starter'),
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_hero_btn_text',
                    'label'       => esc_html__('Hero Button Text', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Hero Button Text Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => esc_html__('Book An Appointment', 'ndisee-starter'),
                ]
            );

            new \Kirki\Field\Url(
                [
                    'settings'    => 'ndisee_starter_hero_btn_url',
                    'label'       => esc_html__('Hero Button URL', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Hero Button URL Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => esc_html__('#', 'ndisee-starter'),
                ]
            );



            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_hero_bg_image',
                    'label'       => esc_html__('Hero Background Image', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Hero Background Image Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => ''
                ]
            );

            // hero shape image

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_hero_shape_image',
                    'label'       => esc_html__('Hero Shape Image', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Hero Shape Image Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_front_page_settngs',
                    'default'     => ''
                ]
            );


            /**
             * Customizer Section
             */
            //=========== Hero section ================ //
            new \Kirki\Section(
                    'ndisee_starter_about_page_settngs',
                    [
                        'title'       => esc_html__('About Section', 'ndisee-starter'),
                        'description' => esc_html__('', 'ndisee-starter'),
                        'panel'       => 'ndisee_starter__front_page_customizer',
                        'priority'    => 10,
                    ]
            );

            // About Section Title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_about_title',
                    'label'       => esc_html__('About Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your About Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ndisee_starter_kses('Experts in delivering quality disability support services.', 'ndisee-starter'),
                ]
            );

            // About Section Sub Title

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_about_subtitle',
                    'label'       => esc_html__('About Sub Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your About Sub Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ndisee_starter_kses('  Who We are ', 'ndisee-starter'),
                ]
            );

            // descrption 

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_about_description',
                    'label'       => esc_html__('About Description', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your About Description Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ndisee_starter_kses('  With our team of dedicated experts and state-of-the-art technology <br> to help you regain your independence and rediscover your capabilities. ', 'ndisee-starter'),
                ]
            );

            // about button

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_about_btn_text',
                    'label'       => esc_html__('About Button Text', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your About Button Text Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => esc_html__('Read More', 'ndisee-starter'),
                ]
            );

            new \Kirki\Field\Url(
                [
                    'settings'    => 'ndisee_starter_about_btn_url',
                    'label'       => esc_html__('About Button URL', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your About Button URL Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => esc_html__('#', 'ndisee-starter'),
                ]
            );

            // about image

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_about_image',
                    'label'       => esc_html__('About Image', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your About Image Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ''
                ]
            );

            // about image 2


            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_about_image_2',
                    'label'       => esc_html__('About Image 2', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your About Image 2 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ''
                ]
            );

            // about shap 1

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_about_shape_1',
                    'label'       => esc_html__('About Shape 1', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your About Shape 1 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ''
                ]
            );

            // about shap 2

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_about_shape_2',
                    'label'       => esc_html__('About Shape 2', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your About Shape 2 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ''
                ]
            );

            // about shap 3

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_about_shape_3',
                    'label'       => esc_html__('About Shape 3', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your About Shape 3 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_about_page_settngs',
                    'default'     => ''
                ]
            );




            /**
             * Customizer Section
             */
            //=========== Video section ================ //
            new \Kirki\Section(
                    'ndisee_starter_video_section',
                    [
                        'title'       => esc_html__('Video Section', 'ndisee-starter'),
                        'description' => esc_html__('', 'ndisee-starter'),
                        'panel'       => 'ndisee_starter__front_page_customizer',
                        'priority'    => 10,
                    ]
            );

            // Video Title1

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_video_title1',
                    'label'       => esc_html__('Video Title 1', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Video Title 1 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_video_section',
                    'default'     => esc_html__('Intro', 'ndisee-starter'),
                ]
            );


            // Video Title2

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_video_title2',
                    'label'       => esc_html__('Video Title 2', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Video Title 2 Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_video_section',
                    'default'     => esc_html__('Video', 'ndisee-starter'),
                ]
            );

            // thumbnail Image

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_video_thumbnail',
                    'label'       => esc_html__('Video Thumbnail', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Video Thumbnail Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_video_section',
                    'default'     => ''
                ]
            );

            // video url

            new \Kirki\Field\Url(
                [
                    'settings'    => 'ndisee_starter_video_url',
                    'label'       => esc_html__('Video URL', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Video URL Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_video_section',
                    'default'     => esc_html__('https://www.youtube.com/watch?v=YoOG5H4603Y', 'ndisee-starter'),
                ]
            );

            // shape image

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_video_shape',
                    'label'       => esc_html__('Video Shape', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Video Shape Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_video_section',
                    'default'     => ''
                ]
            );




            /**
             * Customizer Section
             */
            //=========== Video section ================ //
            new \Kirki\Section(
                    'ndisee_starter_blog_section',
                    [
                        'title'       => esc_html__('Blog Section', 'ndisee-starter'),
                        'description' => esc_html__('', 'ndisee-starter'),
                        'panel'       => 'ndisee_starter__front_page_customizer',
                        'priority'    => 10,
                    ]
            );


            // Blog Title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_blog_title',
                    'label'       => esc_html__('Blog Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => esc_html__('Our Blog', 'ndisee-starter'),
                ]
            );

            // Blog Sub Title

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_blog_subtitle',
                    'label'       => esc_html__('Blog Sub Title', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Sub Title Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => ndisee_starter_kses('  Latest News & Updates ', 'ndisee-starter'),
                ]
            );

            // blog description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'ndisee_starter_blog_description',
                    'label'       => esc_html__('Blog Description', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Description Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => ndisee_starter_kses('  With our team of dedicated experts and state-of-the-art technology <br> to help you regain your independence and rediscover your capabilities. ', 'ndisee-starter'),
                ]
            );

            // Blog Button

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_blog_btn_text',
                    'label'       => esc_html__('Blog Button Text', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Button Text Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => esc_html__('View All', 'ndisee-starter'),
                ]
            );

            new \Kirki\Field\Url(
                [
                    'settings'    => 'ndisee_starter_blog_btn_url',
                    'label'       => esc_html__('Blog Button URL', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Button URL Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => esc_html__('#', 'ndisee-starter'),
                ]
            );

            // Blog Shape Image

            new \Kirki\Field\Image(
                [
                    'settings'    => 'ndisee_starter_blog_shape',
                    'label'       => esc_html__('Blog Shape Image', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Blog Shape Image Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => ''
                ]
            );

            // Blog post query

            new \Kirki\Field\Text(
                [
                    'settings'    => 'ndisee_starter_blog_post_query',
                    'label'       => esc_html__('Blog Post Query', 'ndisee-starter'),
                    'description' => esc_html__('Enter Your Blog Post Query Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_blog_section',
                    'default'     => esc_html__('3', 'ndisee-starter'),
                ]
            );

            // blog post category

            
















            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'ndisee_starter_preloader',
                    'label'       => esc_html__('Preloader On/Off', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'ndisee-starter'),
                        'off' => esc_html__('Disable', 'ndisee-starter'),
                    ],
                ]
            );

            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'ndisee_starter_backtotop',
                    'label'       => esc_html__('Back To Top On/Off', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'ndisee-starter'),
                        'off' => esc_html__('Disable', 'ndisee-starter'),
                    ],
                ]
            );










         

            //=========== Header Right ================ //

            new \Kirki\Section(
                    'ndisee_starter_header_top_settings',
                    [
                        'title'       => esc_html__('Header Top Settings', 'ndisee-starter'),
                        'description' => esc_html__('', 'ndisee-starter'),
                        'panel'       => 'ndisee_starter_customizer',
                        'priority'    => 10,
                    ]
            );

            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'header_top_switcher',
                    'label'       => esc_html__('Header Top Swithcer', 'ndisee-starter'),
                    'description' => esc_html__('', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_header_top_settings',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'ndisee-starter'),
                        'off' => esc_html__('Disable', 'ndisee-starter'),
                    ],
                ]
            );

            // header top phone number

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_phone',
                    'label'    => esc_html__('Phone Number', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('+123 456 7890', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            // header top email

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_email',
                    'label'    => esc_html__('Email Address', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('info@ndisablity.com', 'ndisee-starter'),

                    'priority' => 10,

                ]
            );


            // header top location

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_location',
                    'label'    => esc_html__('Location', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('238, Arimantab, Moska - USA.', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            // header top location url

            new \Kirki\Field\Url(
                [
                    'settings' => 'header_top_location_url',
                    'label'    => esc_html__('Location URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('https://www.google.com/maps', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            // header top social Heading

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_social_heading',
                    'label'    => esc_html__('Social Heading', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('Visit Our Social Pages', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            // header top social url

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_facebook_url',
                    'label'    => esc_html__('Facebook URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_twitter_url',
                    'label'    => esc_html__('Twitter URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_instagram_url',
                    'label'    => esc_html__('Instagram URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'header_top_linkedin_url',
                    'label'    => esc_html__('Linkedin URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_top_settings',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            
            









      

           

        


           

            // Header Logo & Style Settings
            new \Kirki\Section(
                'ndisee_starter_header_logo',
                [
                    'title'       => esc_html__('Header Settings', 'ndisee-starter'),
                    'description' => esc_html__('', 'ndisee-starter'),
                    'panel'       => 'ndisee_starter_customizer',
                    'priority'    => 10,
                ]
            );

            new \Kirki\Field\Select(
                [
                    'settings'    => 'ndisee_starter_header_style',
                    'label'       => esc_html__('Select Header Style', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_header_logo',
                    'default'     => 'header-style-11',
                    'placeholder' => esc_html__('Choose an option', 'ndisee-starter'),
                    'choices'     => [
                        'header-style-11' => esc_html__('Header Style 1', 'ndisee-starter'),
                    ],
                ]
            );


            //Header Logo
            new \Kirki\Field\Image(
                [
                    'settings'    => 'header_logo',
                    'label'       => esc_html__('Header Logo', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Logo Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_header_logo',
                    'default'     => get_template_directory_uri() . '/assets/img/logo/logo-red.png',
                ]
            );


          


            // Header Logo & Style Settings
            new \Kirki\Section(
                'ndisee_starter_header_side_info',
                [
                    'title'       => esc_html__('Header Side Info', 'ndisee-starter'),
                    'description' => esc_html__('', 'ndisee-starter'),
                    'panel'       => 'ndisee_starter_customizer',
                    'priority'    => 10,
                ]
            );

            //Header Logo
            new \Kirki\Field\Image(
                [
                    'settings'    => 'header_side_logo',
                    'label'       => esc_html__('Header Side Info Logo', 'ndisee-starter'),
                    'description' => esc_html__('Upload Your Logo Here', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_header_side_info',
                    'default'     => get_template_directory_uri() . '/assets/img/logo/logo-red.png',
                ]
            );




            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_title',
                    'label'    => esc_html__('Title', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('Get In Touch', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );





            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_phone',
                    'label'    => esc_html__('Phone', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('(00)45611227890', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_location',
                    'label'    => esc_html__('Address', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('238, Arimantab, Moska - USA.', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Url(
                [
                    'settings' => 'side_info_location_url',
                    'label'    => esc_html__('Address URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('htits://www.google.com/maps/@37.4801311,22.8928877,3z', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'side_info_social_switcher',
                    'label'       => esc_html__('Social Icon Show/Hide', 'ndisee-starter'),
                    'section'     => 'ndisee_starter_header_side_info',
                    'default'     => 'on',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'ndisee-starter'),
                        'off' => esc_html__('Disable', 'ndisee-starter'),
                    ],
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_twitter_url',
                    'label'    => esc_html__('Twitter URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_instagram_url',
                    'label'    => esc_html__('Instagram URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_facebook_url',
                    'label'    => esc_html__('Facebook URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'side_info_dribbble_url',
                    'label'    => esc_html__('Dribbble URL', 'ndisee-starter'),
                    'section'  => 'ndisee_starter_header_side_info',
                    'default'  => esc_html__('#', 'ndisee-starter'),
                    'priority' => 10,
                ]
            );

            



           
        };

       



     
    }
);

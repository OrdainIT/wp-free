<?php

/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package ndisee-starter
 */



// ndisee_starter_search_form
//Popup Search bar Functions

function ndisee_starter_search_form()
{
    $header_right_search_logo = get_theme_mod('header_right_search_logo');
?>

    <!-- search popup start -->
    <div class="search__popup">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12">
                    <div class="search__wrapper">
                        <div class="search__top d-flex justify-content-between align-items-center">
                            <div class="search__logo">
                                <?php if (!empty($header_right_search_logo)): ?>
                                    <a href="<?php echo esc_url(home_url()); ?>">
                                        <img src="<?php echo esc_url($header_right_search_logo); ?>" alt="<?php echo esc_attr__('logo', 'ndisee-starter'); ?>">
                                    </a>
                                <?php else: ?>
                                    <?php ndisee_starter_header_logo(); ?>
                                <?php endif; ?>
                            </div>
                            <div class="search__close">
                                <button type="button" class="search__close-btn search-close-btn">
                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path d="M17 1L1 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                        <path d="M1 1L17 17" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                            stroke-linejoin="round" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <div class="search__form">
                            <form method="get" action="<?php print esc_url(home_url('/')) ?>">
                                <div class="search__input">
                                    <input class="search-input-field" type="text" name="s" placeholder="<?php echo esc_attr__('Type here to search...', 'ndisee-starter'); ?>" value="<?php print esc_attr(get_search_query()); ?>">
                                    <span class="search-focus-border"></span>
                                    <button type="submit">
                                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M9.55 18.1C14.272 18.1 18.1 14.272 18.1 9.55C18.1 4.82797 14.272 1 9.55 1C4.82797 1 1 4.82797 1 9.55C1 14.272 4.82797 18.1 9.55 18.1Z"
                                                stroke="currentColor" stroke-width="1.5" stroke-linecap="round"
                                                stroke-linejoin="round" />
                                            <path d="M19.0002 19.0002L17.2002 17.2002" stroke="currentColor" stroke-width="1.5"
                                                stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- search popup end -->


<?php

}
add_action('search_form_show', 'ndisee_starter_search_form');


/** 
 *
 * ndisee-starter header
 */

function ndisee_starter_check_header()
{
    $ndisee_starter_header_style = function_exists('get_field') ? get_field('header_style') : NULL;
    $ndisee_starter_default_header_style = get_theme_mod('ndisee_starter_header_style', 'header-style-11');

    if ($ndisee_starter_header_style == 'header-style-11' && empty($_GET['s'])) {
        get_template_part('template-parts/header/header-1');
    } elseif ($ndisee_starter_header_style == 'header-style-22' && empty($_GET['s'])) {
        get_template_part('template-parts/header/header-2');
    } elseif ($ndisee_starter_header_style == 'header-style-33' && empty($_GET['s'])) {
        get_template_part('template-parts/header/header-3');
    } else {

        /** default header style **/
        if ($ndisee_starter_default_header_style == 'header-style-22') {
            get_template_part('template-parts/header/header-2');
        } elseif ($ndisee_starter_default_header_style == 'header-style-33') {
            get_template_part('template-parts/header/header-3');
        } else {
            get_template_part('template-parts/header/header-1');
        }
    }
}
add_action('ndisee_starter_header_style', 'ndisee_starter_check_header', 10);

















// Header logo
function ndisee_starter_header_logo()
{
    // Get custom fields or fallback
    $ndisee_starter_logo_on = function_exists('get_field') ? get_field('header_logo_page') : null;
    $default_logo = get_template_directory_uri() . '/assets/img/logo/logo-red.png';

    // Fallback to theme mod if custom field is empty
    $ndisee_starter_site_logo = get_theme_mod('header_logo', $default_logo);

    ?>
    <a href="<?php echo esc_url(home_url('/')); ?>">
        <!-- White Logo -->
        <?php if (!empty($ndisee_starter_logo_on) && !empty($ndisee_starter_logo_on['url'])) : ?>
            <img  src="<?php echo esc_url($ndisee_starter_logo_on['url']); ?>" alt="<?php echo esc_attr('Logo'); ?>">
        <?php else : ?>
            <img  src="<?php echo esc_url($ndisee_starter_site_logo); ?>" alt="<?php echo esc_attr('Logo'); ?>">
        <?php endif; ?>
    </a>
    <?php
}







/**
 * [ndisee_starter_header_menu description]
 * @return [type] [description]
 */

function ndisee_starter_header_menu()
{
    $ndisee_starter_menu = '';

    if (function_exists('get_field') && is_page()) {
        $selected_menu = get_field('select_menu');
    }

    if (! empty($selected_menu) && $selected_menu !== 'Select Menu') {
        $ndisee_starter_menu = wp_nav_menu([
            'menu'           => $selected_menu,
            'theme_location' => 'main-menu',
            'menu_class'     => '',
            'container'      => '',
            'fallback_cb'    => 'ndisee_starter_Navwalker_Class::fallback',
            'walker'         => new ndisee_starter_Navwalker_Class(),
            'echo'           => false, // Capture the output instead of echoing it
        ]);
    } else {
        $ndisee_starter_menu = wp_nav_menu([
            'theme_location' => 'main-menu',
            'menu_class'     => '',
            'container'      => '',
            'fallback_cb'    => 'ndisee_starter_Navwalker_Class::fallback',
            'walker'         => new ndisee_starter_Navwalker_Class(),
            'echo'           => false, // Capture the output instead of echoing it
        ]);
    }

    // Replace the class in the captured menu markup
    $ndisee_starter_menu = str_replace("menu-item-has-children", "has-dropdown", $ndisee_starter_menu);

    // Output the sanitized menu
    echo wp_kses_post($ndisee_starter_menu);
}











/**
 *
 * ndisee-starter footer
 */
// Action Hook to trigger the footer check
add_action('ndisee_starter_footer_style', 'ndisee_starter_check_footer', 10);

function ndisee_starter_check_footer()
{
    $field_footer_style = function_exists('get_field') ? get_field('field_footer_style') : '';
    $page_field_select_footer = function_exists('get_field') ? get_field('page_field_select_footer') : '';
    // Get the selected footer styles
    $ndisee_starter_default_footer_styles = get_theme_mod('ndisee_starter_default_footer', 'footer-style-1');
    $ndisee_starter_custom_footer = get_theme_mod('ndisee_starter_custom_footer', '');

// footer style page  support

    if ($field_footer_style == 'footer-style-1' && empty($_GET['s'])) {
        get_template_part('template-parts/footer/footer-1');
    } elseif ($field_footer_style === 'custom-footer' && !empty($page_field_select_footer)) {
        ndisee_starter_render_elementor_footer($page_field_select_footer);
    } else {

        /** default header style **/
        if ($ndisee_starter_default_footer_styles === 'custom-footer' && !empty($ndisee_starter_custom_footer)) {
            ndisee_starter_render_elementor_footer($ndisee_starter_custom_footer);
        }  else {
            get_template_part('template-parts/footer/footer-1');
        }
    }


}

function ndisee_starter_render_elementor_footer($footer_id)
{
    // Ensure Elementor is active
    if (class_exists('\Elementor\Plugin')) {
        // Get Elementor content for the selected footer ID
        $footer_content = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($footer_id);

        // Check if content exists
        if (!empty($footer_content)) {
            echo ndisee_starter_kses($footer_content);
        } else {
            echo '<p>' . esc_html__('The selected custom footer has no content.', 'ndisee-starter') . '</p>';
        }
    } else {
        // Fallback if Elementor is not active
        echo '<p>' . esc_html__('Elementor plugin is not active. Please activate Elementor to display the custom footer.', 'ndisee-starter') . '</p>';
    }
}






/**
 * Fetch custom footer posts for the footer select field in Customizer
 */
function ndisee_starter_get_custom_footer()
{
    $footers = [];

    $custom_footers = get_posts([
        'post_type'      => 'header-footer',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
    ]);

    if (!empty($custom_footers)) {
        foreach ($custom_footers as $footer) {
            $footers[$footer->ID] = $footer->post_title;
        }
    }

    return $footers;
}







// ndisee_starter_copyright_text
function ndisee_starter_copyright_text()
{
    print get_theme_mod('footer_copywrite_text', ndisee_starter_kses('Copyright © 2025 <span><a href="/">Ndisee Starter</a></span>. All Rights Reserved Created by <span><a href="#">Ordianit</a></span>', 'ndisee-starter'));
}



/**
 *
 * pagination
 */
if (!function_exists('ndisee_starter_pagination')) {

    function _ndisee_starter_pagi_callback($pagination)
    {
        return $pagination;
    }

    //page navegation
    function ndisee_starter_pagination($prev, $next, $pages, $args)
    {
        global $wp_query, $wp_rewrite;
        $menu = '';
        $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;

        if ($pages == '') {
            global $wp_query;
            $pages = $wp_query->max_num_pages;

            if (!$pages) {
                $pages = 1;
            }
        }

        $pagination = [
            'base'      => add_query_arg('paged', '%#%'),
            'format'    => '',
            'total'     => $pages,
            'current'   => $current,
            'prev_text' => $prev,
            'next_text' => $next,
            'type'      => 'array',
        ];

        //rewrite permalinks
        if ($wp_rewrite->using_permalinks()) {
            $pagination['base'] = user_trailingslashit(trailingslashit(remove_query_arg('s', get_pagenum_link(1))) . 'page/%#%/', 'paged');
        }

        if (!empty($wp_query->query_vars['s'])) {
            $pagination['add_args'] = ['s' => get_query_var('s')];
        }

        $pagi = '';
        if (paginate_links($pagination) != '') {
            $paginations = paginate_links($pagination);
            $pagi .= '<ul>';
            foreach ($paginations as $key => $pg) {
                $pagi .= '<li>' . $pg . '</li>';
            }
            $pagi .= '</ul>';
        }

        print _ndisee_starter_pagi_callback($pagi);
    }
}








// ndisee_starter_kses_intermediate
function ndisee_starter_kses_intermediate($string = '')
{
    return wp_kses($string, ndisee_starter_get_allowed_html_tags('intermediate'));
}

function ndisee_starter_get_allowed_html_tags($level = 'basic')
{
    $allowed_html = [
        'b'      => [],
        'i'      => [],
        'u'      => [],
        'em'     => [],
        'br'     => [],
        'abbr'   => [
            'title' => [],
        ],
        'span'   => [
            'class' => [],
        ],
        'strong' => [],
        'a'      => [
            'href'  => [],
            'title' => [],
            'class' => [],
            'id'    => [],
        ],
    ];

    if ($level === 'intermediate') {
        $allowed_html['a'] = [
            'href' => [],
            'title' => [],
            'class' => [],
            'id' => [],
        ];
        $allowed_html['div'] = [
            'class' => [],
            'id' => [],
        ];
        $allowed_html['img'] = [
            'src' => [],
            'class' => [],
            'alt' => [],
        ];
        $allowed_html['del'] = [
            'class' => [],
        ];
        $allowed_html['ins'] = [
            'class' => [],
        ];
        $allowed_html['bdi'] = [
            'class' => [],
        ];
        $allowed_html['i'] = [
            'class' => [],
            'data-rating-value' => [],
        ];
    }

    return $allowed_html;
}



// WP kses allowed tags
// ----------------------------------------------------------------------------------------
function ndisee_starter_kses($raw)
{

    $allowed_tags = array(
        'a'                         => array(
            'class'   => array(),
            'href'    => array(),
            'rel'  => array(),
            'title'   => array(),
            'target' => array(),
        ),
        'abbr'                      => array(
            'title' => array(),
        ),
        'b'                         => array(),
        'blockquote'                => array(
            'cite' => array(),
        ),
        'cite'                      => array(
            'title' => array(),
        ),
        'code'                      => array(),
        'del'                    => array(
            'datetime'   => array(),
            'title'      => array(),
        ),
        'dd'                     => array(),
        'div'                    => array(
            'class'   => array(),
            'title'   => array(),
            'style'   => array(),
        ),
        'dl'                     => array(),
        'dt'                     => array(),
        'em'                     => array(),
        'h1'                     => array(),
        'h2'                     => array(),
        'h3'                     => array(),
        'h4'                     => array(),
        'h5'                     => array(),
        'h6'                     => array(),
        'i'                         => array(
            'class' => array(),
        ),
        'img'                    => array(
            'alt'  => array(),
            'class'   => array(),
            'height' => array(),
            'src'  => array(),
            'width'   => array(),
        ),
        'li'                     => array(
            'class' => array(),
        ),
        'ol'                     => array(
            'class' => array(),
        ),
        'p'                         => array(
            'class' => array(),
        ),
        'q'                         => array(
            'cite'    => array(),
            'title'   => array(),
        ),
        'span'                      => array(
            'class'   => array(),
            'title'   => array(),
            'style'   => array(),
        ),
        'iframe'                 => array(
            'width'         => array(),
            'height'     => array(),
            'scrolling'     => array(),
            'frameborder'   => array(),
            'allow'         => array(),
            'src'        => array(),
        ),
        'strike'                 => array(),
        'br'                     => array(),
        'strong'                 => array(),
        'data-wow-duration'            => array(),
        'data-wow-delay'            => array(),
        'data-wallpaper-options'       => array(),
        'data-stellar-background-ratio'   => array(),
        'ul'                     => array(
            'class' => array(),
        ),
        'svg' => array(
            'class' => true,
            'aria-hidden' => true,
            'aria-labelledby' => true,
            'role' => true,
            'xmlns' => true,
            'width' => true,
            'height' => true,
            'viewbox' => true, // <= Must be lower case!
        ),
        'g'     => array('fill' => true),
        'title' => array('title' => true),
        'path'  => array('d' => true, 'fill' => true,),
    );

    if (function_exists('wp_kses')) { // WP is here
        $allowed = wp_kses($raw, $allowed_tags);
    } else {
        $allowed = $raw;
    }

    return $allowed;
}

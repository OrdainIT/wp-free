<?php

/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package ndisee-starter
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function ndisee_starter_body_classes($classes)
{
    // Adds a class of hfeed to non-singular pages.
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }
    // Adds a class of no-sidebar when there is no sidebar present.
    if (!is_active_sidebar('sidebar-1')) {
        $classes[] = 'no-sidebar';
    }
    if (function_exists('tutor')) {
        $user_name = sanitize_text_field(get_query_var('tutor_student_username'));
        $get_user = tutor_utils()->get_user_by_login($user_name);
    }

    if (!empty($get_user)) {
        $classes[] = 'profile-breadcrumb';
    }

    // Get the RTL option value from the Customizer
    $ndisee_starter_rtl = get_option('ndisee_starter_rtl', 'off');

    // Check if RTL is enabled
    if ($ndisee_starter_rtl === 'on') {
        // Add the 'ndisee_starter_rtl' class to the body classes
        $classes[] = 'ndisee_starter_rtl';
    }

    return $classes;

    return $classes;
}
add_filter('body_class', 'ndisee_starter_body_classes');






// Dynamic CSS Function

function ndisee_starter_theme_colors()
{
?>
    <style type="text/css">
        .it-shop-widget-checkbox ul li label::before {
            content: url('<?php echo esc_url(get_template_directory_uri(), 'ndisee-starter'); ?>/assets/img/inner/check.svg');
        }

        blockquote.wp-block-quote::before {
            content: "";
            background-image: url('http://localhost/ndisee-starter/wp-content/themes/ndisee-starter/assets/img/shape/quote.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            position: absolute;
            top: 8%;
            right: 5%;
            width: 160px;
            height: 160px;
            z-index: -1;
            opacity: .5;
        }

        :root {
            --it-theme-1: <?php echo esc_attr(get_theme_mod('ndisee_starter_theme_pcolor', '#011D4E')); ?>;
            --it-common-red: <?php echo esc_attr(get_theme_mod('ndisee_starter_theme_scolor', '#DC1D1C')); ?>;
        }
    </style>
<?php
}
add_action('wp_head', 'ndisee_starter_theme_colors');


function ndisee_starter_dynamic_font()
{
    $body_font_array = get_theme_mod('ndisee_starter_typography_setting');
    $ndisee_starter_typography_h1 = get_theme_mod('ndisee_starter_typography_h1');
    $ndisee_starter_typography_h2 = get_theme_mod('ndisee_starter_typography_h2');
    $ndisee_starter_typography_h3 = get_theme_mod('ndisee_starter_typography_h3');
    $ndisee_starter_typography_h4 = get_theme_mod('ndisee_starter_typography_h4');
    $ndisee_starter_typography_h5 = get_theme_mod('ndisee_starter_typography_h5');
    $ndisee_starter_typography_h6 = get_theme_mod('ndisee_starter_typography_h6');


    if (! empty($body_font_array)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($body_font_array['font-family']) ? esc_html($body_font_array['font-family']) : 'inter';
        $font_weight   = isset($body_font_array['variant']) && $body_font_array['variant'] === 'regular' ? '400' : esc_html($body_font_array['variant']);
        $font_color    = isset($body_font_array['color']) ? esc_html($body_font_array['color']) : '#5E5F62';
        $font_size     = isset($body_font_array['font-size']) ? esc_html($body_font_array['font-size']) : '16px';  // Provide default size
        $line_height   = isset($body_font_array['line-height']) ? esc_html($body_font_array['line-height']) : '1.3'; // Provide default line-height


        $body_font_css = sprintf(
            "body {
                font-family: '%s',Sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $body_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h1)) {

        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h1['font-family']) ? esc_html($ndisee_starter_typography_h1['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h1['variant']) ? ($ndisee_starter_typography_h1['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h1['variant'])) : '600'; // Default to '400' if 'variant' is not set
        $font_color    = isset($ndisee_starter_typography_h1['color']) ? esc_html($ndisee_starter_typography_h1['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h1['font-size']) ? esc_html($ndisee_starter_typography_h1['font-size']) : '40px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h1['line-height']) ? esc_html($ndisee_starter_typography_h1['line-height']) : '1.2'; // Provide default line-height

        $H1_font_css = sprintf(
            "h1 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H1_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h2)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h2['font-family']) ? esc_html($ndisee_starter_typography_h2['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h2['variant']) && $ndisee_starter_typography_h2['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h2['variant']);
        $font_color    = isset($ndisee_starter_typography_h2['color']) ? esc_html($ndisee_starter_typography_h2['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h2['font-size']) ? esc_html($ndisee_starter_typography_h2['font-size']) : '32px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h2['line-height']) ? esc_html($ndisee_starter_typography_h2['line-height']) : '1.2'; // Provide default line-height

        $H2_font_css = sprintf(
            "h2 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H2_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h3)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h3['font-family']) ? esc_html($ndisee_starter_typography_h3['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h3['variant']) && $ndisee_starter_typography_h3['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h3['variant']);
        $font_color    = isset($ndisee_starter_typography_h3['color']) ? esc_html($ndisee_starter_typography_h3['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h3['font-size']) ? esc_html($ndisee_starter_typography_h3['font-size']) : '28px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h3['line-height']) ? esc_html($ndisee_starter_typography_h3['line-height']) : '1.2'; // Provide default line-height

        $H3_font_css = sprintf(
            "h3 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H3_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h4)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h4['font-family']) ? esc_html($ndisee_starter_typography_h4['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h4['variant']) && $ndisee_starter_typography_h4['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h4['variant']);
        $font_color    = isset($ndisee_starter_typography_h4['color']) ? esc_html($ndisee_starter_typography_h4['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h4['font-size']) ? esc_html($ndisee_starter_typography_h4['font-size']) : '24px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h4['line-height']) ? esc_html($ndisee_starter_typography_h4['line-height']) : '1.2'; // Provide default line-height

        $H4_font_css = sprintf(
            "h4 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H4_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h5)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h5['font-family']) ? esc_html($ndisee_starter_typography_h5['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h5['variant']) && $ndisee_starter_typography_h5['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h5['variant']);
        $font_color    = isset($ndisee_starter_typography_h5['color']) ? esc_html($ndisee_starter_typography_h5['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h5['font-size']) ? esc_html($ndisee_starter_typography_h5['font-size']) : '23px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h5['line-height']) ? esc_html($ndisee_starter_typography_h5['line-height']) : '1.2'; // Provide default line-height

        $H5_font_css = sprintf(
            "h5 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H5_font_css . '</style>';
    }

    if (! empty($ndisee_starter_typography_h6)) {
        // Ensure that these keys exist, else provide default values
        $font_family   = isset($ndisee_starter_typography_h6['font-family']) ? esc_html($ndisee_starter_typography_h6['font-family']) : 'Anek Bangla';
        $font_weight   = isset($ndisee_starter_typography_h6['variant']) && $ndisee_starter_typography_h6['variant'] === 'regular' ? '600' : esc_html($ndisee_starter_typography_h6['variant']);
        $font_color    = isset($ndisee_starter_typography_h6['color']) ? esc_html($ndisee_starter_typography_h6['color']) : '#1F0723';
        $font_size     = isset($ndisee_starter_typography_h6['font-size']) ? esc_html($ndisee_starter_typography_h6['font-size']) : '16px';  // Provide default size
        $line_height   = isset($ndisee_starter_typography_h6['line-height']) ? esc_html($ndisee_starter_typography_h6['line-height']) : '1.2'; // Provide default line-height

        $H6_font_css = sprintf(
            "h6 {
                font-family: '%s', sans-serif; 
                font-weight: %s; 
                color: %s;
                font-size: %s;
                line-height: %s;
            }",
            $font_family,
            $font_weight,
            $font_color,
            $font_size,
            $line_height
        );

        // Output the CSS
        echo '<style>' . $H6_font_css . '</style>';
    }
}
add_action('wp_head', 'ndisee_starter_dynamic_font');




/**
 * Get tags.
 */


function ndisee_starter_get_tag()
{
    $html = '';
    if (has_tag()) {
        $html .= '<div class="postbox-tag-content">';
        $html .= get_the_tag_list('', ' ', '');
        $html .= '</div>';
    }
    return $html;
}

function ndisee_starter_get_tag2()
{
    $html2 = '';
    if (has_tag()) {
        $html2 .= '<span class="it-blog-2-tag-title">';
        $html2 .= get_the_tag_list('', ' ', '');
        $html2 .= '</span>';
    }
    return $html2;
}





/**
 * Get categories.
 */
function ndisee_starter_get_category()
{

    $categories = get_the_category(get_the_ID());
    $x = 0;
    foreach ($categories as $category) {

        if ($x == 2) {
            break;
        }
        $x++;
        print '<a class="news-tag" href="' . get_category_link($category->term_id) . '">' . $category->cat_name . '</a>';
    }
}

/** img alt-text **/
function ndisee_starter_img_alt_text($img_er_id = null)
{
    $image_id = $img_er_id;
    $image_alt = get_post_meta($image_id, '_wp_attachment_image_alt', false);
    $image_title = get_the_title($image_id);

    if (!empty($image_id)) {
        if ($image_alt) {
            $alt_text = get_post_meta($image_id, '_wp_attachment_image_alt', false);
        } else {
            $alt_text = get_the_title($image_id);
        }
    } else {
        $alt_text = esc_html__('Image Alt Text', 'ndisee-starter');
    }

    return $alt_text;
}

// ndisee_starter_ofer_sidebar_func
function ndisee_starter_offer_sidebar_func()
{
    if (is_active_sidebar('offer-sidebar')) {

        dynamic_sidebar('offer-sidebar');
    }
}
add_action('ndisee_starter_offer_sidebar', 'ndisee_starter_offer_sidebar_func', 20);

// ndisee_starter_service_sidebar
function ndisee_starter_service_sidebar_func()
{
    if (is_active_sidebar('services-sidebar')) {

        dynamic_sidebar('services-sidebar');
    }
}
add_action('ndisee_starter_service_sidebar', 'ndisee_starter_service_sidebar_func', 20);

// ndisee_starter_portfolio_sidebar
function ndisee_starter_portfolio_sidebar_func()
{
    if (is_active_sidebar('portfolio-sidebar')) {

        dynamic_sidebar('portfolio-sidebar');
    }
}
add_action('ndisee_starter_portfolio_sidebar', 'ndisee_starter_portfolio_sidebar_func', 20);

// ndisee_starter_faq_sidebar
function ndisee_starter_faq_sidebar_func()
{
    if (is_active_sidebar('faq-sidebar')) {

        dynamic_sidebar('faq-sidebar');
    }
}
add_action('ndisee_starter_faq_sidebar', 'ndisee_starter_faq_sidebar_func', 20);



// add Class in Menu Item

function add_class_to_last_four_menu_items($items, $args)
{
    // Convert menu items into an array
    $menu_items = wp_get_nav_menu_items($args->menu);

    // Count total number of menu items
    $total_items = count($menu_items);

    // Loop through the menu items
    foreach ($items as $key => $item) {
        // Add class to the last 4 items
        if ($key >= $total_items - 4) {
            $items[$key]->classes[] = 'last_menu_item';
        }
    }

    return $items;
}
add_filter('wp_nav_menu_objects', 'add_class_to_last_four_menu_items', 10, 2);

// get All Contact Form


function od_get_contact_form_7()
{
    $choices = [];
    $forms = get_posts(array(
        'post_type'   => 'wpcf7_contact_form',
        'numberposts' => -1
    ));

    if ($forms) {
        foreach ($forms as $form) {
            $choices[$form->ID] = $form->post_title;
        }
    }

    return $choices;
}


function od_wpcf7_custom_submit_button($form)
{
    // Use regex to match the submit button, excluding the closing '/>'
    $form = preg_replace_callback(
        '/<input([^>]*)type="submit"([^>]*)value="([^"]*)".*?>/',
        function ($matches) {
            // Extract the dynamic button text from the value attribute
            $button_text = $matches[3];

            // Extract classes from the input field (if any)
            preg_match('/class="([^"]*)"/', $matches[0], $class_matches);
            $classes = isset($class_matches[1]) ? $class_matches[1] : '';

            // Add the default "it-btn" class
            $new_classes = trim($classes . ' ');

            // Return the custom button markup with dynamic text, class, and SVG icon
            return '<button type="submit" class="' . esc_attr($new_classes) . '">
                        ' . esc_html($button_text) . '
                        
                    </button>';
        },
        $form
    );

    return $form;
}

add_filter('wpcf7_form_elements', 'od_wpcf7_custom_submit_button');



// post View Count



// add menu class in widget menu
function ndisee_starter_class_to_widget_nav_menu_container($args, $instance)
{
    // Check if 'container_class' is already set, if not, set it as an empty string
    if (!isset($args['container_class'])) {
        $args['container_class'] = ''; // Initialize container_class if not set
    }

    // Append your custom class to the existing 'container_class'
    $args['container_class'] .= 'it-footer-widget-menu';

    return $args;
}
add_filter('widget_nav_menu_args', 'ndisee_starter_class_to_widget_nav_menu_container', 10, 2);


// Custom Class Add function in menu li

// Step 1: Add a custom field to the menu item settings
function add_custom_class_to_menu_item($item_id, $item, $depth, $args)
{
    // Retrieve the current custom class value
    $custom_class = get_post_meta($item_id, '_menu_item_custom_li_class', true);
?>
    <p class="field-custom-class description description-wide">
        <label for="edit-menu-item-custom-li-class-<?php echo esc_attr($item_id, 'ndisee-starter'); ?>">
            <?php esc_html_e('Custom LI Class', 'ndisee-starter'); ?><br>
            <input type="text" id="edit-menu-item-custom-li-class-<?php echo esc_attr($item_id, 'ndisee-starter'); ?>"
                class="widefat code edit-menu-item-custom-li-class"
                name="menu-item-custom-li-class[<?php echo esc_attr($item_id, 'ndisee-starter'); ?>]"
                value="<?php echo esc_attr($custom_class); ?>" />
        </label>
    </p>
<?php
}
add_action('wp_nav_menu_item_custom_fields', 'add_custom_class_to_menu_item', 10, 4);

// Step 2: Save the custom field value
function save_custom_class_menu_item($menu_id, $menu_item_db_id)
{
    if (isset($_POST['menu-item-custom-li-class'][$menu_item_db_id])) {
        $custom_class = sanitize_text_field($_POST['menu-item-custom-li-class'][$menu_item_db_id]);
        update_post_meta($menu_item_db_id, '_menu_item_custom_li_class', $custom_class);
    } else {
        delete_post_meta($menu_item_db_id, '_menu_item_custom_li_class');
    }
}
add_action('wp_update_nav_menu_item', 'save_custom_class_menu_item', 10, 2);

// Step 3: Add the custom class to the <li> element
function apply_custom_li_class_to_menu_item($classes, $item, $args, $depth)
{
    // Get the custom class from the post meta
    $custom_class = get_post_meta($item->ID, '_menu_item_custom_li_class', true);
    if (!empty($custom_class)) {
        $classes[] = esc_attr($custom_class);
    }
    return $classes;
}
add_filter('nav_menu_css_class', 'apply_custom_li_class_to_menu_item', 10, 4);



// Mega Menu Class

// Add a custom field for mega menu class in menu item settings
function add_mega_menu_class_to_menu_item($item_id, $item, $depth, $args)
{
    // Retrieve the current mega menu class value
    $mega_menu_class = get_post_meta($item_id, '_menu_item_mega_menu_class', true);
?>
    <p class="field-custom-class description description-wide">
        <label for="edit-menu-item-mega-menu-class-<?php echo esc_attr($item_id, 'ndisee-starter'); ?>">
            <?php esc_html_e('Mega Menu Class', 'ndisee-starter'); ?><br>
            <input type="text" id="edit-menu-item-mega-menu-class-<?php echo esc_attr($item_id, 'ndisee-starter'); ?>"
                class="widefat code edit-menu-item-mega-menu-class"
                name="menu-item-mega-menu-class[<?php echo esc_attr($item_id, 'ndisee-starter'); ?>]"
                value="<?php echo esc_attr($mega_menu_class); ?>" />
        </label>
    </p>
<?php
}
add_action('wp_nav_menu_item_custom_fields', 'add_mega_menu_class_to_menu_item', 10, 4);

// Save the mega menu class value
function save_mega_menu_class_menu_item($menu_id, $menu_item_db_id)
{
    if (isset($_POST['menu-item-mega-menu-class'][$menu_item_db_id])) {
        $mega_menu_class = sanitize_text_field($_POST['menu-item-mega-menu-class'][$menu_item_db_id]);
        update_post_meta($menu_item_db_id, '_menu_item_mega_menu_class', $mega_menu_class);
    } else {
        delete_post_meta($menu_item_db_id, '_menu_item_mega_menu_class');
    }
}
add_action('wp_update_nav_menu_item', 'save_mega_menu_class_menu_item', 10, 2);





<?php

/**
 * ndisee_starter_scripts description
 * @return [type] [description]
 */
function ndisee_starter_scripts()
{

    /**
     * all css files
     */






    wp_enqueue_style('ndisee-starter-google-fonts', ndisee_starter_fonts_url(), array(), null);
    // Enqueue normal styles
    wp_enqueue_style('bootstrap', ndisee_starter_THEME_CSS_DIR . 'bootstrap.min.css', array());
    wp_enqueue_style('slick', ndisee_starter_THEME_CSS_DIR . 'slick.css', array());
    wp_enqueue_style('custom-animation', ndisee_starter_THEME_CSS_DIR . 'custom-animation.css', array());
    wp_enqueue_style('nice-select', ndisee_starter_THEME_CSS_DIR . 'nice-select.css', []);
    wp_enqueue_style('swiper-bundle', ndisee_starter_THEME_CSS_DIR . 'swiper-bundle.css', []);
    wp_enqueue_style('font-awesome-pro', ndisee_starter_THEME_CSS_DIR . 'font-awesome-pro.css', []);
    wp_enqueue_style('magnific-popup', ndisee_starter_THEME_CSS_DIR . 'magnific-popup.css', []);
    wp_enqueue_style('spacing', ndisee_starter_THEME_CSS_DIR . 'spacing.css', []);
    wp_enqueue_style('theme-core', ndisee_starter_THEME_CSS_DIR . 'main.css', [], time());


    wp_enqueue_style('theme-unit', ndisee_starter_THEME_CSS_DIR . 'theme-unit.css', [], time());
    wp_enqueue_style('theme-custom', ndisee_starter_THEME_CSS_DIR . 'theme-custom.css', []);
    wp_enqueue_style('theme-style', get_stylesheet_uri());




    // all js
    wp_enqueue_script('bootstrap-bundle', ndisee_starter_THEME_JS_DIR . 'bootstrap.bundle.min.js', ['jquery'], '', true);
    wp_enqueue_script('slick', ndisee_starter_THEME_JS_DIR . 'slick.min.js', ['jquery'], '', true);
    wp_enqueue_script('magnific-popup', ndisee_starter_THEME_JS_DIR . 'magnific-popup.js', ['jquery'], '', true);
    wp_enqueue_script('purecounter', ndisee_starter_THEME_JS_DIR . 'purecounter.js', ['jquery'], '', true);
    wp_enqueue_script('wow', ndisee_starter_THEME_JS_DIR . 'wow.js', ['jquery'], '', true);
    wp_enqueue_script('nice-select', ndisee_starter_THEME_JS_DIR . 'nice-select.js', ['jquery'], '', true);
    wp_enqueue_script('range-slider', ndisee_starter_THEME_JS_DIR . 'range-slider.js', ['jquery'], '', true);
    wp_enqueue_script('swiper-bundle', ndisee_starter_THEME_JS_DIR . 'swiper-bundle.js', ['jquery'], '', true);
    wp_enqueue_script('isotope-pkgd', ndisee_starter_THEME_JS_DIR . 'isotope-pkgd.js', ['imagesloaded'], false, true);
    wp_enqueue_script('slider', ndisee_starter_THEME_JS_DIR . 'slider.js', ['jquery'], '', true);
    wp_enqueue_script('ndisee-starter-main', ndisee_starter_THEME_JS_DIR . 'main.js', ['jquery'], time(), true);












    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'ndisee_starter_scripts');

function ndisee_starter_enqueue_admin_script()
{

    wp_enqueue_style('ndisee-starter-admin', ndisee_starter_THEME_CSS_DIR . 'admin.css', [], time());
    // Enqueue the admin.js script only in the admin area
    wp_enqueue_script('ndisee-starter-admin', ndisee_starter_THEME_JS_DIR . 'admin.js', ['jquery'], '', true);
}
add_action('admin_enqueue_scripts', 'ndisee_starter_enqueue_admin_script');


/*
Register Fonts
 */
function ndisee_starter_fonts_url()
{
    $font_url = '';

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ('off' !== _x('on', 'Google font: on or off', 'ndisee-starter')) {
        $font_url = 'https://fonts.googleapis.com/css2?family=Anek+Bangla:wght@100..800&family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=Sora:wght@100..800&family=Space+Grotesk:wght@300..700&display=swap" rel="stylesheet';
    }
    return $font_url;
}

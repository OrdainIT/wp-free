<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ndisee-starter
 */
$ndisee_starter_blog_btn = get_theme_mod('ndisee_starter_blog_btn', 'Read More');
$ndisee_starter_blog_btn_switch = get_theme_mod('ndisee_starter_blog_btn_switch', true);
$ndisee_starter_bolg_colum_style = get_theme_mod('ndisee_starter_bolg_colum_style', true);
$ndisee_starter_bolg_style = get_theme_mod('ndisee_starter_bolg_style', 'no-sidebar');
$ndisee_starter_video_url = function_exists('get_field') ? get_field('format_link') : NULL;

if (is_single()):
?>


    <article id="post-<?php the_ID(); ?>" <?php post_class('postbox-item format-video'); ?>>
        <?php if (has_post_thumbnail()): ?>
            <div class="postbox-main-thumb mb-40 p-relative">
                <img class="wow img-anim-top" data-wow-duration="1.5s" data-wow-delay="0.1s" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                <?php if (!empty($ndisee_starter_video_url)): ?>
                    <a class="postbox-video-btn popup-video ripple-red" href="<?php echo esc_url($ndisee_starter_video_url); ?>">
                        <svg width="25" height="20" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                        </svg>
                    </a>
                <?php endif; ?>

            </div>
        <?php endif; ?>
        <?php get_template_part('template-parts/blog/blog-meta'); ?>
        <div class="postbox-content-box">
            <h4 class="postbox-title">
                <?php
                $title = get_the_title(); // Get the title
                $words = explode(' ', $title); // Split the title into an array of words

                if (count($words) > 9) {
                    // Insert the <br> tag after the 9th word
                    $words[8] .= '<br>'; // Add the <br> tag to the 9th word (index 8)
                }

                // Join the words back into a string
                $modified_title = implode(' ', $words);

                // Output the modified title, allowing the <br> tag
                echo wp_kses($modified_title, ['br' => []]);
                ?>
            </h4>

            <?php the_content(); ?>

        </div>
        <div class="postbox-tag-box mb-65">
            <div class="row align-items-center">
                <div class="col-xl-7 col-lg-6 col-md-6">
                    <div class="postbox-tag d-flex align-items-center">
                        <h3 class="postbox-tag-title"><?php echo esc_html__('Tag:', 'ndisee-starter'); ?></h3>
                        <?php echo ndisee_starter_get_tag(); ?>

                    </div>
                </div>
                <?php if (function_exists('get_share_buttons')) : ?>
                    <div class="col-xl-5 col-lg-6 col-md-6">
                        <div class="postbox-share d-flex align-items-center justify-content-md-end">
                            <h3 class="postbox-tag-title"><?php echo esc_html__('Share:', 'ndisee-starter'); ?></h3>
                            <div class="postbox-share-content">

                                <?php
                                $post_url = get_permalink();
                                $post_title = get_the_title();
                                get_share_buttons($post_url, $post_title);
                                ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </article>

<?php else: ?>
    
    





        <article id="post-<?php the_ID(); ?>" <?php post_class('postbox-thumb-box mb-60 format-video'); ?>>
            <?php if (has_post_thumbnail()): ?>
                <div class="postbox-main-thumb mb-40 p-relative">
                    <img class="wow img-anim-top" data-wow-duration="1.5s" data-wow-delay="0.1s" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php if (!empty($ndisee_starter_video_url)): ?>
                        <a class="postbox-video-btn popup-video ripple-red" href="<?php echo esc_url($ndisee_starter_video_url); ?>">
                            <svg width="25" height="20" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                            </svg>
                        </a>
                    <?php endif; ?>

                </div>
            <?php endif; ?>
            <div class="postbox-content-box">
                <?php get_template_part('template-parts/blog/blog-meta'); ?>
                <h4 class="postbox-title">
                    <a href="<?php the_permalink(); ?>">
                        <?php
                        $title = get_the_title(); // Get the title
                        $words = explode(' ', $title); // Split the title into an array of words

                        if (count($words) > 9) {
                            // Insert the <br> tag after the 9th word
                            $words[8] .= '<br>'; // Add the <br> tag to the 9th word (index 8)
                        }

                        // Join the words back into a string
                        $modified_title = implode(' ', $words);

                        // Output the modified title, allowing the <br> tag
                        echo wp_kses($modified_title, ['br' => []]);
                        ?>
                    </a>



                </h4>
                <p class="mb-25"><?php echo wp_trim_words(get_the_content(), 30, '...'); ?></p>
                <?php if (!empty($ndisee_starter_blog_btn_switch)): ?>
                    <a class="it-btn-sm" href="<?php the_permalink(); ?>">
                        <?php echo esc_html($ndisee_starter_blog_btn, 'ndisee-starter'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </article>










<?php
endif; ?>
<?php

/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ndisee-starter
 */
global $post;


$ndisee_starter_blog_btn = get_theme_mod('ndisee_starter_blog_btn', 'Read More');
$ndisee_starter_blog_btn_switch = get_theme_mod('ndisee_starter_blog_btn_switch', true);
$ndisee_starter_bolg_colum_style = get_theme_mod('ndisee_starter_bolg_colum_style', true);
$ndisee_starter_bolg_style = get_theme_mod('ndisee_starter_bolg_style', 'no-sidebar');
if (is_single()) : ?>

    <article id="post-<?php the_ID(); ?>" <?php post_class('postbox-item format-standard'); ?>>
        <?php if (has_post_thumbnail()): ?>
            <div class="postbox-thumb text-center mb-40">
                <img class="wow img-anim-top" data-wow-duration="1.5s" data-wow-delay="0.1s" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
            </div>
        <?php endif; ?>
        <?php get_template_part('template-parts/blog/blog-meta'); ?>
        <div class="postbox-content-box">
            <h4 class="postbox-title">
                <?php
                $title = get_the_title(); // Get the title
                $words = explode(' ', $title); // Split the title into an array of words

                if (count($words) > 9) {
                    // Insert the <br> tag after the 9th word
                    $words[8] .= '<br>'; // Add the <br> tag to the 9th word (index 8)
                }

                // Join the words back into a string
                $modified_title = implode(' ', $words);

                // Output the modified title, allowing the <br> tag
                echo wp_kses($modified_title, ['br' => []]);
                ?>
            </h4>

            <?php the_content(); ?>

        </div>
        <div class="postbox-tag-box mb-65">
            <div class="row align-items-center">
                <div class="col-xl-7 col-lg-6 col-md-6">
                    <div class="postbox-tag d-flex align-items-center">
                        <h3 class="postbox-tag-title"><?php echo esc_html__('Tag:', 'ndisee-starter'); ?></h3>
                        <?php echo ndisee_starter_get_tag(); ?>

                    </div>
                </div>
                <?php if (function_exists('get_share_buttons')) : ?>
                    <div class="col-xl-5 col-lg-6 col-md-6">
                        <div class="postbox-share d-flex align-items-center justify-content-md-end">
                            <h3 class="postbox-tag-title"><?php echo esc_html__('Share:', 'ndisee-starter'); ?></h3>
                            <div class="postbox-share-content">

                                <?php
                                $post_url = get_permalink();
                                $post_title = get_the_title();
                                get_share_buttons($post_url, $post_title);
                                ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </article>




<?php else: ?>
    <?php if ($ndisee_starter_bolg_colum_style ==='3' && $ndisee_starter_bolg_style === 'no-sidebar') {
    ?>




        <article id="post-<?php the_ID(); ?>"
            <?php post_class('col-xl-4 col-lg-4 col-md-6 wow itfadeUp mb-30 format-standard'); ?>
            data-wow-duration="<?php echo esc_attr(get_post_meta(get_the_ID(), 'wow_duration', true) ?: '.9s'); ?>"
            data-wow-delay="<?php echo esc_attr(get_post_meta(get_the_ID(), 'wow_delay', true) ?: '.3s'); ?>">

            <div class="it-blog-item zoom white-bg mb-30">
                <?php if (has_post_thumbnail()): ?>
                    <div class="it-blog-thumb mb-35 img-zoom">
                        <a href="<?php the_permalink(); ?>">
                            <img class="w-100" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                        </a>
                    </div>
                <?php endif; ?>

                <div class="it-blog-content">
                    <?php get_template_part('template-parts/blog/blog_meta'); ?>
                    <h4 class="it-blog-title mb-35">
                        <a class="border-line-black-2" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h4>
                    <?php if (!empty($ndisee_starter_blog_btn_switch)): ?>
                        <a class="it-btn-sm theme-bg" href="<?php the_permalink(); ?>">
                            <?php echo esc_html($ndisee_starter_blog_btn, 'ndisee-starter'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </article>







    <?php


    } elseif ($ndisee_starter_bolg_colum_style === '2'&& $ndisee_starter_bolg_style === 'no-sidebar') {
    ?>

        <article id="post-<?php the_ID(); ?>"
            <?php post_class('col-xl-6 col-lg-6 col-md-6 wow itfadeUp mb-30 format-standard'); ?>
            data-wow-duration="<?php echo esc_attr(get_post_meta(get_the_ID(), 'wow_duration', true) ?: '.9s'); ?>"
            data-wow-delay="<?php echo esc_attr(get_post_meta(get_the_ID(), 'wow_delay', true) ?: '.3s'); ?>">

            <div class="it-blog-item zoom white-bg mb-30">
                <?php if (has_post_thumbnail()): ?>
                    <div class="it-blog-thumb mb-35 img-zoom">
                        <a href="<?php the_permalink(); ?>">
                            <img class="w-100" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                        </a>
                    </div>
                <?php endif; ?>

                <div class="it-blog-content">
                    <?php get_template_part('template-parts/blog/blog_meta'); ?>
                    <h4 class="it-blog-title mb-35">
                        <a class="border-line-black-2" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                    </h4>
                    <?php if (!empty($ndisee_starter_blog_btn_switch)): ?>
                        <a class="it-btn-sm theme-bg" href="<?php the_permalink(); ?>">
                            <?php echo esc_html($ndisee_starter_blog_btn, 'ndisee-starter'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </article>


    <?php
    } else {
    ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class('postbox-thumb-box mb-60 format-standard'); ?>>
            <?php if (has_post_thumbnail()): ?>
                <div class="postbox-main-thumb mb-40">
                    <img class="wow img-anim-top" data-wow-duration="1.5s" data-wow-delay="0.1s" src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'full')); ?>" alt="<?php echo esc_attr(get_the_title()); ?>">
                </div>
            <?php endif; ?>
            <div class="postbox-content-box">
                <?php get_template_part('template-parts/blog/blog-meta'); ?>
                <h4 class="postbox-title">
                    <a href="<?php the_permalink(); ?>">
                        <?php
                        $title = get_the_title(); // Get the title
                        $words = explode(' ', $title); // Split the title into an array of words

                        if (count($words) > 9) {
                            // Insert the <br> tag after the 9th word
                            $words[8] .= '<br>'; // Add the <br> tag to the 9th word (index 8)
                        }

                        // Join the words back into a string
                        $modified_title = implode(' ', $words);

                        // Output the modified title, allowing the <br> tag
                        echo wp_kses($modified_title, ['br' => []]);
                        ?>
                    </a>



                </h4>
                <p class="mb-25"><?php echo wp_trim_words(get_the_content(), 30, '...'); ?></p>
                <?php if (!empty($ndisee_starter_blog_btn_switch)): ?>
                    <a class="it-btn-sm" href="<?php the_permalink(); ?>">
                        <?php echo esc_html($ndisee_starter_blog_btn, 'ndisee-starter'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </article>









    <?php
    } ?>


<?php endif; ?>
<?php

/**
 * Template part for displaying footer layout one
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package ndisee-starter
 */

$footer__bottom_right_text = get_theme_mod('footer__bottom_right_text');
$ndisee_starter_footer_social_switcher = get_theme_mod('ndisee_starter_footer_social_switcher', false);
$ndisee_starter_footer_facebook_url = get_theme_mod('ndisee_starter_footer_facebook_url', esc_html__('#', 'ndisee-starter'));
$ndisee_starter_footer_instagram_url = get_theme_mod('ndisee_starter_footer_instagram_url', esc_html__('#', 'ndisee-starter'));
$ndisee_starter_footer_twitter_url = get_theme_mod('ndisee_starter_footer_twitter_url', esc_html__('#', 'ndisee-starter'));
$ndisee_starter_footer_youtube_url = get_theme_mod('ndisee_starter_footer_youtube_url', esc_html__('#', 'ndisee-starter'));


$select_footer_bg_image_acf = function_exists('get_field') ? get_field('select_footer_bg_image') : '';
$ndisee_starter_footer_1_bg_image = get_theme_mod('ndisee_starter_footer_bg_image', '');

// Check conditions in the desired priority order
if (!empty($select_footer_bg_image_acf)) {
   $footer_bg_image = $select_footer_bg_image_acf; // ACF image has the highest priority
} elseif (!empty($ndisee_starter_footer_1_bg_image)) {
   $footer_bg_image = $ndisee_starter_footer_1_bg_image; // Customizer image is second
} else {
   $footer_bg_image = get_template_directory_uri() . '/assets/img/shape/footer-bg-1-1.png'; // Default image
}


$ndisee_starter_footer_copywrite_wrap = $ndisee_starter_footer_social_switcher ? 'col-xl-6 col-lg-4' : 'col-12 full-width';





$footer_cta_title = get_theme_mod('footer_cta_title');
$select_contact_form = get_theme_mod('select_contact_form');
$footer_cta_switcher = get_theme_mod('footer_cta_switcher');






?>


<footer>

   <!-- footer-area-start -->
   <div class="it-footer-bg theme-bg" data-background="<?php echo esc_url($footer_bg_image, 'ndisee-starter'); ?>">
      <?php if (!empty($footer_cta_switcher)): ?>
         <div class="it-newsletter-area pt-130">
            <div class="container">
               <div class="it-newsletter-wrap">
                  <div class="row align-items-center">
                     <div class="col-xl-6 col-lg-6 col-md-6">
                        <div class="it-newsletter-left">
                           <h4 class="it-newsletter-title">
                              <?php echo ndisee_starter_kses($footer_cta_title); ?>
                           </h4>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6">
                        <!-- contac form shortocde dynamice -->

                        <?php echo do_shortcode('[contact-form-7  id="' . $select_contact_form . '"]'); ?>

                       
                     </div>
                  </div>
               </div>
            </div>
         </div>
      <?php endif; ?>
      <?php if (is_active_sidebar('footer-1') or is_active_sidebar('footer-2') or is_active_sidebar('footer-3') or is_active_sidebar('footer-4')): ?>
         <div class="it-footer-3-area mb-50 pt-90">
            <div class="container">
               <div class="it-footer-3-wrap">
                  <div class="row">
                     <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-50"
                        data-wow-delay=".3s">
                        <?php dynamic_sidebar('footer-1'); ?>
                     </div>
                     <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-50">
                        <?php dynamic_sidebar('footer-2'); ?>
                     </div>
                     <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-50">
                        <?php dynamic_sidebar('footer-3'); ?>
                     </div>
                     <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6 mb-50">
                        <?php dynamic_sidebar('footer-4'); ?>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      <?php endif; ?>
      <div class="it-copyright-area it-copyright-style-2 it-copyright-ptb">
         <div class="container">
            <div class="row">
               <div class="<?php echo esc_attr($ndisee_starter_footer_copywrite_wrap); ?>">
                  <div class="it-copyright-content text-center text-lg-start">
                     <p class="mb-0 text-white"><?php ndisee_starter_copyright_text(); ?></p>

                  </div>
               </div>
               <?php if (!empty($ndisee_starter_footer_social_switcher)): ?>
                  <div class="col-xl-6 col-lg-4">
                     <div class="it-copyright-social text-center text-lg-end">


                        <span><?php echo esc_html($footer__bottom_right_text, 'ndisee-starter'); ?></span>
                        <?php if (!empty($ndisee_starter_footer_facebook_url)): ?>
                           <a href="<?php echo esc_url($ndisee_starter_footer_facebook_url, 'ndisee-starter'); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($ndisee_starter_footer_twitter_url)): ?>
                           <a href="<?php echo esc_url($ndisee_starter_footer_twitter_url, 'ndisee-starter'); ?>"><i class="fa-brands fa-twitter"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($ndisee_starter_footer_instagram_url)): ?>
                           <a href="<?php echo esc_url($ndisee_starter_footer_instagram_url, 'ndisee-starter'); ?>"><i class="fa-brands fa-instagram"></i></a>
                        <?php endif; ?>
                        <?php if (!empty($ndisee_starter_footer_youtube_url)): ?>
                           <a href="<?php echo esc_url($ndisee_starter_footer_youtube_url, 'ndisee-starter'); ?>"><i class="fa-brands fa-linkedin"></i></a>
                        <?php endif; ?>
                     </div>
                  </div>
               <?php endif; ?>
            </div>
         </div>
      </div>

   </div>
   <!-- footer-area-end -->

</footer>
<?php

/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package ndisee-starter
 */

get_header();


?>






<section class="blog_unit ">
    <?php

 
        get_template_part('template-parts/blog/single/single_style_1');
 

    ?>
</section>

<?php


get_footer();

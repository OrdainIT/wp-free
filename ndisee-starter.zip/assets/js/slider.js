(function ($) {
  ("use strict");

  ////////////////////////////////////////////////////
  //  Swiper Js
  const team2swiper = new Swiper(".it-team-active-2", {
    // Optional parameters
    speed: 1500,
    loop: true,
    slidesPerView: 4,
    spaceBetween: 35,
    autoplay: true,
    breakpoints: {
      1400: {
        slidesPerView: 4,
      },
      1200: {
        slidesPerView: 3,
      },
      992: {
        slidesPerView: 3,
      },
      768: {
        slidesPerView: 2,
      },
      576: {
        slidesPerView: 2,
      },
      0: {
        slidesPerView: 1,
      },
    },
    navigation: {
      prevEl: ".slider-prev",
      nextEl: ".slider-next",
    },
  });

  ////////////////////////////////////////////////////
  // 18. Swiper Js
  const postBoxswiper = new Swiper(".postbox-thumb-slider-active", {
    speed: 1000,
    loop: true,
    slidesPerView: 1,
    spaceBetween: 0,
    autoplay: true,
    effect: "fade",
    breakpoints: {
      1400: {
        slidesPerView: 1,
      },
      1200: {
        slidesPerView: 1,
      },
      992: {
        slidesPerView: 1,
      },
      768: {
        slidesPerView: 1,
      },
      576: {
        slidesPerView: 1,
      },
      0: {
        slidesPerView: 1,
      },
    },
    navigation: {
      prevEl: ".postbox-arrow-prev",
      nextEl: ".postbox-arrow-next",
    },
  });
})(jQuery);

<?php

/**
 * The template for displaying Comments
 *
 * The area of the page that contains comments and the comment form.
 */
?>
<?php
// If the current post is protected by a password and the visitor has not yet 
// entered the password we will return early without loading the comments.
// ----------------------------------------------------------------------------------------
if (post_password_required()) {
    return;
}
?>

<?php if (have_comments() || comments_open()) : ?>
    <div id="comments" class="postbox-comment">

        <?php if (get_comments_number() >= 1): ?>
            <div class="postbox-comment mb-45">


                <?php
                $comment_no = number_format_i18n(get_comments_number());
                $comment_text = (!empty($comment_no) and ($comment_no > 1)) ? esc_html__(' Comments', 'ndisee-starter') : esc_html__(' Comment ', 'ndisee-starter');
                $comment_no = (!empty($comment_no) and ($comment_no > 0)) ? '<h3 class="postbox-comment-title mb-35">' . esc_html('0' . $comment_no .  $comment_text) . '</h3>' : ' ';
                print sprintf("%s", $comment_no);
                ?>

                <div class="postbox-comment-item">
                    <div class="postbox-comment-content mb-25">
                        <ul>
                            <?php
                            wp_list_comments([
                                'style'       => 'ul',
                                'callback'    => 'ndisee_starter_comment',
                                'avatar_size' => 90,
                                'short_ping'  => true,
                            ]);
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (get_comment_pages_count() > 1 && get_option('page_comments')): ?>
            <div class="comment-pagination mb-50 d-none">
                <nav id="comment-nav-below" class="comment-navigation" role="navigation">
                    <h1 class="screen-reader-text"><?php esc_html_e('Comment navigation', 'ndisee-starter'); ?></h1>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="nav-previous "><?php previous_comments_link(esc_html__('&larr; Older ', 'ndisee-starter')); ?></div>
                        </div>
                        <div class="col-md-6">
                            <div class="nav-next "><?php next_comments_link(esc_html__('Newer &rarr;', 'ndisee-starter')); ?></div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </nav><!-- #comment-nav-below -->
            </div>
        <?php endif; // check for comment navigation 
        ?>


        <?php
        $post_id = '';
        // Your existing code to set $post_id...

        $commenter = wp_get_current_commenter();
        $user = wp_get_current_user();
        $user_identity = $user->exists() ? $user->display_name : '';

        $req = get_option('require_name_email');
        $aria_req = ($req ? " aria-required='true'" : '');

        $fields = array(
            'author' => '<div class="row"><div class="col-md-6 mb-20"><div class="postbox-review-input"><input placeholder="' .  esc_attr__('Enter Name *', 'ndisee-starter') . '" id="author" class="tp-form-control" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30"' . $aria_req . ' /></div></div>',
            'email'  => '<div class="col-md-6 mb-20"><div class="postbox-review-input"><input placeholder="' .  esc_attr__('Enter Email *', 'ndisee-starter') . '" id="email" name="email" class="tp-form-control" type="email" value="' . esc_attr($commenter['comment_author_email']) . '" size="30"' . $aria_req . ' /></div></div>',
            'url'    => '<div class="col-md-12 mb-20"><div class="postbox-review-input"><input placeholder="' .  esc_attr__('Enter Website', 'ndisee-starter') . '" id="url" name="url" class="tp-form-control" type="url" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" /></div></div></div>'
        );

        if (is_user_logged_in()) {
            $cl = 'loginformuser';
        } else {
            $cl = '';
        }

        $defaults = [
            'comment_field' => '
                <div class="row post-input">
                    <div class="col-md-12 mb-20 ' . $cl . '">
                        <div class="postbox-review-message">
                            <textarea placeholder="' . esc_attr__('Write Your Message*', 'ndisee-starter') . '" id="comment" name="comment" cols="45" rows="6" aria-required="true"></textarea>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            ',

            'submit_button' => '
            <div class="postbox-review-button">
                <button class="it-btn-red hover-2" type="submit">
                    ' . esc_html__('Post Comment', 'ndisee-starter') . '
                </button>
            </div>
        ',
            'fields' => $fields,
            // Rest of your defaults...
        ];

        // Reorder comment fields
        if (!function_exists('ndisee_starter_reorder_comment_fields')) {
            function ndisee_starter_reorder_comment_fields($fields)
            {
                if (isset($fields['comment'])) {
                    $comment_field = $fields['comment'];
                    unset($fields['comment']);
                    $fields = array_merge(array('comment' => $comment_field), $fields);
                }
                return $fields;
            }
        }
        add_filter('comment_form_fields', 'ndisee_starter_reorder_comment_fields');

        comment_form($defaults);

       
        ?>

    </div><!-- #comments -->
<?php endif;

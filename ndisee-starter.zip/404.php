<?php

/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package ndisee-starter
 */

get_header();

$_image_404_setup = get_theme_mod('_image_404_setup', get_template_directory_uri() . '/assets/img/error/error.png');
$ndisee_starter_error_link_text = get_theme_mod('ndisee_starter_error_link_text', __('Back to Home', 'ndisee-starter'));
$ndisee_starter_error_title = get_theme_mod('ndisee_starter_error_title', ndisee_starter_kses('Oops! That page can’t be found.', 'ndisee-starter'));
?>

<div class="it-error-area pt-120 pb-120">
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-xxl-12 col-xl-7 col-lg-7 col-md-9">
            <div class="it-error-thumb text-center mb-60">
               <img src="<?php echo esc_url($_image_404_setup); ?>" alt="">
            </div>
         </div>
      </div>
      <div class="row">
         <div class="col-12">
            <div class="it-error-content text-center">
               <h5 class="it-section-title"><?php echo ndisee_starter_kses($ndisee_starter_error_title, 'ndisee-starter'); ?></h5>
               <div class="it-fade-anim" data-fade-from="top" data-ease="bounce" data-delay=".5">
                  <a class="it-btn-red hover-2" href="<?php echo esc_url(home_url()); ?>">
                     <?php echo esc_html($ndisee_starter_error_link_text); ?>
                  </a>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>







<?php
get_footer();

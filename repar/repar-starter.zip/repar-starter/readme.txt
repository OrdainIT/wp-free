=== Repar Starter ===
Contributors: Ordainit
Requires at least: 5.9
Tested up to: 6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: blog, portfolio, education, one-column, two-columns, custom-colors, custom-menu, custom-logo, sticky-post, threaded-comments, right-sidebar, left-sidebar, grid-layout, custom-background, rtl-language-support, featured-images, wide-blocks, editor-style, full-site-editing, block-patterns, block-styles, style-variations, template-editing, translation-ready





== Description ==

Repar Starter is fast, fully customizable & beautiful WordPress theme suitable for blog, personal portfolio, business website and WooCommerce storefront



== Copyright ==
This theme, like WordPress, is distributed under the terms of GPL.

Repar Starter bundles the following third-party resources:


== Resources ==

## CSS and JavaScript Credits

This project uses Bootstrap for CSS and JavaScript.
- Framework: Bootstrap
- License: [MIT License](https://github.com/twbs/bootstrap/blob/main/LICENSE)
- Source: [https://getbootstrap.com](https://getbootstrap.com)

- Framework: Fontawesome Pro
-License: MIT License
-URL: http://opensource.org/licenses/mit-license.html

- Framework: Wow Js
-License: MIT License
-URL: https://raw.githubusercontent.com/graingert/WOW/master/LICENSE

Google Web Fonts ( Barlow Condensed ) By Google - https://google.com
* Barlow Condensed, This is the normal family, Licensed under Open Font License,
Source: https://fonts.google.com/specimen/Barlow+Condensed
* Inter, This is the normal family, Licensed under Open Font License,
Source: https://fonts.google.com/specimen/Inter


- Images
Screenshoot Image Made From Figma Free Tools
-source: https://www.figma.com/legal/community-free-resource-license/
screenshoot.png


== Changelog ==

= 0.0.3 (Released: February, 2025) =

<?php

/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package repar-starter
 * 
 */


?>

<!doctype html>
<html <?php language_attributes(); ?> <?php
                                       $repar_starter_rtl = get_option('od_rtl', 'off'); // Get RTL setting
                                       if ($repar_starter_rtl === 'on') {
                                          echo 'dir="rtl"';  // Add dir="rtl" when RTL is enabled
                                       }
                                       ?>>

<head>
   <meta charset="<?php bloginfo('charset'); ?>">
   <?php if (is_singular() && pings_open(get_queried_object())): ?>
   <?php endif; ?>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="profile" href="https://gmpg.org/xfn/11">
   <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

   <?php wp_body_open(); ?>



   <div id="site-main" class="site-main">

      <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e('Skip to content', 'repar-starter'); ?></a>

      <?php
      $repar_starter_preloader = get_theme_mod('repar_starter_preloader', false);
      $repar_starter_backtotop = get_theme_mod('repar_starter_backtotop', false);


      ?>
      <?php if (!empty($repar_starter_preloader)): ?>
         <!-- preloader -->
         <div id="preloader">
            <div class="preloader">
               <span></span>
               <span></span>
            </div>
         </div>
         <!-- preloader end  -->
      <?php endif; ?>

      <?php if (!empty($repar_starter_backtotop)): ?>
         <!-- back-to-top-start  -->
         <button class="scroll-top scroll-to-target" data-target="html">
            <i class="far fa-angle-double-up"></i>
         </button>
         <!-- back-to-top-end  -->
      <?php endif; ?>






      <?php do_action('search_form_show'); ?>

      <!-- header start -->
      <?php do_action('repar_starter_header_style'); ?>
      <!-- header end -->


      <!-- wrapper-box start -->
      <?php do_action('repar_starter_before_main_content'); ?>
<?php 

/**
 * Template part for displaying footer layout one
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package repar-starter
*/

$footer_bg_img = get_theme_mod( 'repar_starter_footer_bg_image' );
$repar_starter_footer_top_space = function_exists('get_field') ? get_field('repar_starter_footer_top_space') : '0';
$repar_starter_footer_bg_url_from_page = function_exists( 'get_field' ) ? get_field( 'repar_starter_footer_bg' ) : '';
$repar_starter_footer_bg_color_from_page = function_exists( 'get_field' ) ? get_field( 'repar_starter_footer_bg_color' ) : '';
$repar_starter_footer_social_switcher = get_theme_mod( 'repar_starter_footer_social_switcher', false );
$repar_starter_footer_facebook_url = get_theme_mod( 'repar_starter_footer_facebook_url', esc_html__( '#', 'repar-starter' )  );
$repar_starter_footer_pinterest_url = get_theme_mod( 'repar_starter_footer_pinterest_url', esc_html__( '#', 'repar-starter' ) );
$repar_starter_footer_linkedin_url = get_theme_mod( 'repar_starter_footer_linkedin_url', esc_html__( '#', 'repar-starter' ) );
$repar_starter_footer_youtube_url = get_theme_mod( 'repar_starter_footer_youtube_url', esc_html__( '#', 'repar-starter' ) );


$repar_starter_footer_bg_image = get_theme_mod( 'repar_starter_footer_bg_image', '' );
if ( empty($repar_starter_footer_bg_image) ) {
    $repar_starter_footer_bg_image = get_template_directory_uri().'/assets/img/common/footer.png';
}






?> 

  <footer class="footer-style-1">


      <!-- footer-area-start -->
      <div class="it-footer-bg black-bg-2 z-index-1" data-background="<?php echo esc_url( $repar_starter_footer_bg_image, 'repar-starter' );?>">
           <?php if ( is_active_sidebar('footer-1') OR is_active_sidebar('footer-2') OR is_active_sidebar('footer-3') OR is_active_sidebar('footer-4')  ): ?>
         <div class="it-footer-area pt-130 pb-30">
            <div class="container">
               <div class="row">

                

              <?php
                   
                        if ( is_active_sidebar( 'footer-1' ) ) {
                            print '<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-duration=".9s"
                            data-wow-delay=".3s">';
                            dynamic_sidebar( 'footer-1' );
                            print '</div>';
                        }

                        if ( is_active_sidebar( 'footer-2' ) ) {
                            print '<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-duration=".9s"
                            data-wow-delay=".5s">';
                            dynamic_sidebar( 'footer-2' );
                            print '</div>';
                        }

                        if ( is_active_sidebar( 'footer-3' ) ) {                
                            print '<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-duration=".9s"
                            data-wow-delay=".7s">';
                        dynamic_sidebar( 'footer-3' );
                            print '</div>';
                        }

                        if ( is_active_sidebar( 'footer-4' ) ) {
                            print '<div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6 mb-50 wow itfadeUp" data-wow-duration=".9s"
                            data-wow-delay=".9s">';
                            dynamic_sidebar( 'footer-4' );
                            print '</div>';
                        }
                   
                ?> 
               </div>
            </div>
         </div>
         <?php endif;?>
         <div class="it-copyright-area it-copyright-border">
            <div class="container">
               <div class="row align-items-center">
                  <div class="col-xl-6 col-lg-6 col-md-7 wow itfadeUp" data-wow-duration=".9s"
                  data-wow-delay=".3s">
                     <div class="it-copyright-left text-center text-md-start">
                         <p><?php repar_starter_copyright_text();?></p>
                     </div>
                  </div>
                  <?php if ( !empty($repar_starter_footer_social_switcher) ):?>
                  <div class="col-xl-6 col-lg-6 col-md-5 d-none d-md-block wow itfadeUp" data-wow-duration=".9s"
                  data-wow-delay=".3s">
                     <div class="it-copyright-social text-center text-md-end">
                        <?php if ( !empty($repar_starter_footer_facebook_url) ):?>  
                        <a href="<?php echo esc_url( $repar_starter_footer_facebook_url, 'repar-starter' );?>">
                           <span>
                              <i class="fa-brands fa-facebook"></i>
                           </span>
                            </a>
                        <?php endif;?>
                        <?php if ( !empty($repar_starter_footer_pinterest_url) ):?>  
                        <a href="<?php echo esc_url( $repar_starter_footer_pinterest_url, 'repar-starter' );?>">
                           <span>
                              <i class="fa-brands fa-pinterest"></i>
                           </span>
                        </a>
                        <?php endif;?>
                        <?php if ( !empty($repar_starter_footer_linkedin_url) ):?>  
                        <a href="<?php echo esc_url( $repar_starter_footer_linkedin_url, 'repar-starter' );?>">
                           <span>
                              <i class="fa-brands fa-linkedin"></i>
                           </span>
                        </a>
                        <?php endif;?>
                        <?php if ( !empty($repar_starter_footer_youtube_url) ):?>  
                        <a href="<?php echo esc_url( $repar_starter_footer_youtube_url, 'repar-starter' );?>">
                           <span>
                              <i class="fa-brands fa-youtube"></i>
                           </span>
                        </a>
                        <?php endif;?>
                     </div>
                  </div>
                  <?php endif;?>
               </div>
            </div>
         </div>

      </div>
      <!-- footer-area-end -->

</footer>

<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package repar-starter
 */
$repar_starter_blog_btn = get_theme_mod( 'repar_starter_blog_btn', 'Read More' );
$repar_starter_blog_btn_switch = get_theme_mod( 'repar_starter_blog_btn_switch', true );
 $repar_starter_bolg_style = get_theme_mod('repar_starter_bolg_style', 'blog-style-1');
$repar_starter_video_url = function_exists( 'get_field' ) ? get_field( 'format_link' ) : NULL;

if ( is_single() ): 
?>
    

<article id="post-<?php the_ID();?>" <?php post_class( 'postbox-item format-video' );?>>
   
            <?php if ( has_post_thumbnail() ): ?>
               <div class="postbox-main-thumb p-relative mb-35">
                 <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
                 <?php  if(!empty($repar_starter_video_url)):?>
                  <a class="it-about-2-video-btn popup-video" href="<?php echo esc_url($repar_starter_video_url);?>">
                     <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                     </svg>
                  </a>  
                 <?php endif;?>
               </div>
            <?php endif;?>
        <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>
    <div class="postbox-content-box">
        <h3 class="postbox-title mb-25"><?php the_title();?></h3>
       <?php the_content();?>
       <?php
            wp_link_pages( [
                'before'      => '<div class="page-links">' . esc_html__( 'Pages:', 'repar-starter' ),
                'after'       => '</div>',
                'link_before' => '<span class="page-number">',
                'link_after'  => '</span>',
            ] );
        ?>
    </div>
    
    <div class="postbox-meta mb-20">
        <div class="row align-items-center">
            <div class="col-xl-8">
                <?php $tags = repar_starter_get_tag(); ?>
                <?php if(!empty($tags)):?>
                <div class="postbox-tag d-flex align-items-center">
                    <h3 class="postbox-tag-title"><?php echo esc_html__('Tag:', 'repar-starter');?></h3>
                    <?php echo repar_starter_get_tag();?>
                </div>
                <?php endif;?>
            </div>
            <?php if (function_exists('get_share_buttons')) : ?>
                <div class="col-xl-4">
                    <div class="postbox-share d-flex align-items-center justify-content-xl-end">
                        <h3 class="postbox-tag-title"><?php echo esc_html__('Share:', 'repar-starter');?></h3>
                        <div class="postbox-share-content">
                            
                            <?php 
                                $post_url = get_permalink();
                                $post_title = get_the_title();
                                get_share_buttons($post_url, $post_title);
                            ?>
                        </div>
                    </div>
                </div>
            <?php endif;?>
        </div>
    </div>
   
 </article>

<?php else: ?>
        <?php if($repar_starter_bolg_style == 'blog-style-2'){
            ?>
          <article  id="post-<?php the_ID();?>" <?php post_class( 'col mb-30 format-video' );?>>
                  <div class="it-blog-item">
                  <?php if ( has_post_thumbnail() ): ?>
                     <div class="it-blog-thumb fix p-relative">
                     <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
                     <?php  if(!empty($repar_starter_video_url)):?>
                        <a class="it-about-2-video-btn popup-video" href="<?php echo esc_url($repar_starter_video_url);?>">
                           <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                           </svg>
                        </a>  
                     <?php endif;?>
                     </div>
                  <?php endif;?>
                     <div class="it-blog-content">
                        <div class="it-blog-meta">
                           <span>  <?php the_author(); ?></span>
                           <span><?php comments_number();?></span>
                        </div>
                        <h4 class="it-blog-title"><a class="border-line-black" href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                        <?php if($repar_starter_blog_btn_switch):?>
                        <a href="<?php the_permalink();?>" class="it-btn-grey-sm orange-btn">
                           <?php echo esc_html($repar_starter_blog_btn, 'repar-starter');?>
                              <svg width="21" height="12" viewBox="0 0 21 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z" fill="currentcolor"></path>
                              </svg>
                           </i>
                        </a>
                        <?php endif;?>
                     </div>
                  </div>
        </article>

        


            <?php
            
        }else{
              ?>

         <article  id="post-<?php the_ID();?>" <?php post_class( 'postbox-thumb-box mb-60 format-video' );?>>
            <?php if ( has_post_thumbnail() ): ?>
               <div class="postbox-main-thumb p-relative">
                 <?php the_post_thumbnail( 'full', ['class' => 'img-responsive'] );?>
                 <?php  if(!empty($repar_starter_video_url)):?>
                  <a class="it-about-2-video-btn popup-video" href="<?php echo esc_url($repar_starter_video_url);?>">
                     <svg width="9" height="9" viewBox="0 0 9 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M8.08398 4.66237L0.917318 0.524694L0.917318 8.80005L8.08398 4.66237Z" fill="currentcolor"></path>
                     </svg>
                  </a>  
                 <?php endif;?>
               </div>
            <?php endif;?>
               <div class="postbox-content-box">
                     <?php get_template_part( 'template-parts/blog/blog-meta' ); ?>
                     <h4 class="postbox-title">
                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                     </h4>
                     <p class="mt-15 mb-30"><?php echo wp_trim_words(get_the_content(), 20, '...');?></p>
                     <?php if($repar_starter_blog_btn_switch):?>
                     <a class="it-btn orange-bg" href="<?php the_permalink();?>">
                        <?php echo esc_html($repar_starter_blog_btn, 'repar-starter');?>
                     </a>
                     <?php endif;?>
               </div>
         </article>

       


              <?php
        }
        ?>
      

<?php
endif;?>



<?php

/**
 * Template part for displaying header layout one
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package repar-starter
 */

// Header Top info
$header_top_switcher = get_theme_mod('header_top_switcher', false);
$header_top_phone_number = get_theme_mod('header_top_phone_number', __('(00)8757845682', 'repar-starter'));
$header_top_email_id = get_theme_mod('header_top_email_id', __('info@repar-starter.com', 'repar-starter'));
$header_top_Address = get_theme_mod('header_top_Address', __('Moon ave, New York, 2020 NY US.', 'repar-starter'));
$header_top_Address_url = get_theme_mod('header_top_Address_url', __('https://goo.gl/maps/qzqY2PAcQwUz1BYN9', 'repar-starter'));
$header_top_right_menu = get_theme_mod('header_top_right_menu');
$header_top_button2 = get_theme_mod('header_top_button2',  __('Help You', 'repar-starter'));
$header_top_button2_url = get_theme_mod('header_top_button2_url',  __('#', 'repar-starter'));
$header_top_ac_button = get_theme_mod('header_top_ac_button',  __('Login', 'repar-starter'));
$header_top_ac_button_url = get_theme_mod('header_top_ac_button_url',  __('#', 'repar-starter'));

//social Links
$header_social_switcher = get_theme_mod('header_social_switcher', false);
$header_social_facebook_url = get_theme_mod('header_social_facebook_url', __('#', 'repar-starter'));
$header_social_linkedin_url = get_theme_mod('header_social_linkedin_url', __('#', 'repar-starter'));
$header_social_instagram_url = get_theme_mod('header_social_instagram_url', __('#', 'repar-starter'));
$header_social_twitter_url = get_theme_mod('header_social_twitter_url', __('#', 'repar-starter'));
$header_top_slider = get_theme_mod('header_top_slider');

//Header Right info 

$header_right_switcher = get_theme_mod('header_right_switcher', false);
$header_right_text_area = get_theme_mod('header_right_text_area');
$header_right_btn_text = get_theme_mod('header_right_btn_text', __('Book A Shedule', 'repar-starter'));
$header_right_btn_url = get_theme_mod('header_right_btn_url', __('#', 'repar-starter'));
$account_login_url = get_theme_mod('account_login_url', __('#', 'repar-starter'));
$header_right_icon_img = get_theme_mod('header_right_icon_img', 'repar-starter');




$header_right_remove_container = $header_right_switcher ? 'col-xxl-6 col-xl-7 d-none d-xl-block' : 'col-xxl-9 col-xl-9 d-none d-xl-block text-end';
$header_right__sidebarmenu = $header_right_switcher ? 'd-none  col-xl-3 col-6' : 'd-sm-block d-none d-xl-none col-xl-3 col-6';

?>









<header class="header-height">
   <?php if (!empty($header_top_switcher)): ?>
      <!-- header-top-area-start -->
      <div class="it-header-top-area it-header-top-ptb black-bg">
         <div class="container-fluid p-0">
            <div class="row">
               <div class="col-xl-8 col-lg-6 col-md-7 col-sm-6 d-none d-sm-block">
                  <div class="it-header-top-left d-flex align-items-center">
                     <?php if (!empty($header_social_switcher)): ?>
                        <div class="it-header-top-social-box">
                           <?php if (!empty($header_social_facebook_url)): ?>
                              <a href="<?php echo esc_url($header_social_facebook_url, 'repar-starter'); ?>"><i class="fa-brands fa-facebook-f"></i></a>
                           <?php endif; ?>
                           <?php if (!empty($header_social_instagram_url)): ?>
                              <a href="<?php echo esc_url($header_social_instagram_url, 'repar-starter'); ?>"><i class="fa-brands fa-instagram"></i></a>
                           <?php endif; ?>
                           <?php if (!empty($header_social_twitter_url)): ?>
                              <a href="<?php echo esc_url($header_social_instagram_url, 'repar-starter'); ?>">
                                 <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path
                                       d="M9.99414 7L14.9941 0L13.9941 0L8.99414 6L4.99414 0L-0.00585938 0L5.99414 9L-0.00585938 16H0.994141L6.99414 10L10.9941 16H15.9941L9.99414 7ZM7.99414 9L6.99414 8L1.99414 1H3.99414L7.99414 7L8.99414 8L13.9941 15H11.9941L7.99414 9Z"
                                       fill="currentcolor" />
                                 </svg>
                              </a>
                           <?php endif; ?>
                           <?php if (!empty($header_social_linkedin_url)): ?>
                              <a href="<?php echo esc_url($header_social_linkedin_url, 'repar-starter'); ?>"><i class="fa-brands fa-linkedin"></i></a>
                           <?php endif; ?>
                        </div>
                     <?php endif; ?>
                     <div class="it-header-top-list-box">
                        <ul>
                           <li class="d-none d-xl-inline-block"><span><i class="fa-solid fa-phone-volume"></i><a class="border-line-white"
                                    href="tel:<?php echo esc_attr($header_top_phone_number, 'repar-starter'); ?>"><?php echo esc_html($header_top_phone_number, 'repar-starter'); ?></a></span></li>
                           <li class="d-none d-lg-inline-block"><span><i class="fa-solid fa-envelope"></i><a class="border-line-white"
                                    href="<?php echo esc_attr($header_top_email_id, 'repar-starter'); ?>"><?php echo esc_html($header_top_email_id, 'repar-starter'); ?></a></span></li>
                        </ul>
                     </div>
                  </div>
               </div>
               <div class="col-xl-4 col-lg-6 col-md-5 col-sm-6">
                  <div class="it-header-top-right d-flex justify-content-sm-end justify-content-center align-items-center">
                     <div class="it-header-top-loging">
                        <a class="border-line-white" href="<?php echo esc_url($header_top_ac_button_url, 'repar-starter'); ?>"><?php echo esc_html($header_top_ac_button, 'repar-starter'); ?></a>
                        <span>|</span>
                        <a class="border-line-white" href="<?php echo esc_url($header_top_button2_url, 'repar-starter'); ?>"><?php echo esc_html($header_top_button2, 'repar-starter'); ?></a>
                        <span>|</span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- header-top-area-end -->
   <?php endif; ?>
   <!-- header-area-start -->
   <div id="header-sticky" class="it-header-area it-header-ptb white-bg">
      <div class="container container-1745">
         <div class="p-relative">
            <div class="row align-items-center">
               <div class="col-xxl-3 col-xl-3 col-6">
                  <div class="it-header-logo">
                     <!--show header custom logo or site blog info -->
                     <?php if (has_custom_logo()) : ?>
                        <div class="it-header-logo-img">
                           <?php the_custom_logo(); ?>
                        </div>
                     <?php else : ?>
                        <h2 class="it-header-logo-text">
                           <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
                        </h2>
                     <?php endif; ?>
                  </div>
               </div>
               <div class="<?php echo esc_attr($header_right_remove_container, 'repar-starter'); ?>">
                  <div class="it-header-menu">
                     <nav class="it-menu-content">
                        <?php repar_starter_header_menu(); ?>
                     </nav>
                  </div>
               </div>
               <?php if (!empty($header_right_switcher)): ?>
                  <div class="col-xxl-3 col-xl-2 col-6">
                     <div class="it-header-right-action d-flex justify-content-end align-items-center">
                        <div class="it-header-search mr-30 d-none d-md-block">
                           <button class="search-open-btn">
                              <svg width="25" height="25" viewBox="0 0 25 25" fill="none"
                                 xmlns="http://www.w3.org/2000/svg">
                                 <path
                                    d="M24.7628 23.6399L18.3082 17.2884C19.9984 15.452 21.037 13.0234 21.037 10.3509C21.0362 4.63387 16.3273 0 10.5181 0C4.70891 0 0 4.63387 0 10.3509C0 16.0678 4.70891 20.7017 10.5181 20.7017C13.0281 20.7017 15.3301 19.8335 17.1384 18.3902L23.618 24.7667C23.9338 25.0777 24.4463 25.0777 24.7621 24.7667C25.0785 24.4557 25.0785 23.9509 24.7628 23.6399ZM10.5181 19.1092C5.60289 19.1092 1.61836 15.1879 1.61836 10.3509C1.61836 5.51376 5.60289 1.59254 10.5181 1.59254C15.4333 1.59254 19.4178 5.51376 19.4178 10.3509C19.4178 15.1879 15.4333 19.1092 10.5181 19.1092Z"
                                    fill="currentcolor" />
                              </svg>
                           </button>
                        </div>
                        <div class="it-header-bar">
                           <button class="it-menu-bar">
                              <span>
                                 <svg width="24" height="20" viewBox="0 0 24 20" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                       d="M10 18.3333C10 17.4128 10.7462 16.6667 11.6667 16.6667H21.6667C22.5872 16.6667 23.3333 17.4128 23.3333 18.3333C23.3333 19.2538 22.5872 20 21.6667 20H11.6667C10.7462 20 10 19.2538 10 18.3333ZM0 1.66667C0 0.746183 0.746183 0 1.66667 0H21.6667C22.5872 0 23.3333 0.746183 23.3333 1.66667C23.3333 2.58713 22.5872 3.33333 21.6667 3.33333H1.66667C0.746183 3.33333 0 2.58713 0 1.66667ZM0 10C0 9.07953 0.746183 8.33333 1.66667 8.33333H21.6667C22.5872 8.33333 23.3333 9.07953 23.3333 10C23.3333 10.9205 22.5872 11.6667 21.6667 11.6667H1.66667C0.746183 11.6667 0 10.9205 0 10Z"
                                       fill="currentcolor" />
                                 </svg>
                              </span>
                           </button>
                        </div>
                        <div class="it-header-right-tel d-none d-xxl-flex align-items-center">
                           <div class="it-header-right-tel-icon">
                              <span>
                                 <?php if (!empty($header_right_icon_img)): ?>
                                    <img src="<?php echo esc_url($header_right_icon_img, 'repar-starter'); ?>" alt="">
                                 <?php else: ?>
                                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/img/home-01/icon/header-icon.png'); ?>" alt="">
                                 <?php endif; ?>

                              </span>
                           </div>
                           <div class="it-header-right-tel-content">
                              <?php echo repar_starter_kses($header_right_text_area, 'repar-starter'); ?>
                           </div>
                        </div>
                     </div>
                  </div>
               <?php endif; ?>
               <?php if (empty($header_right_switcher)): ?>
                  <div class="col-xxl-3 col-xl-2 col-6 d-xl-none  d-sm-block  ">
                     <div class="it-header-right-action d-flex justify-content-end align-items-center">

                        <div class="it-header-bar">
                           <button class="it-menu-bar">
                              <span>
                                 <svg width="24" height="20" viewBox="0 0 24 20" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                       d="M10 18.3333C10 17.4128 10.7462 16.6667 11.6667 16.6667H21.6667C22.5872 16.6667 23.3333 17.4128 23.3333 18.3333C23.3333 19.2538 22.5872 20 21.6667 20H11.6667C10.7462 20 10 19.2538 10 18.3333ZM0 1.66667C0 0.746183 0.746183 0 1.66667 0H21.6667C22.5872 0 23.3333 0.746183 23.3333 1.66667C23.3333 2.58713 22.5872 3.33333 21.6667 3.33333H1.66667C0.746183 3.33333 0 2.58713 0 1.66667ZM0 10C0 9.07953 0.746183 8.33333 1.66667 8.33333H21.6667C22.5872 8.33333 23.3333 9.07953 23.3333 10C23.3333 10.9205 22.5872 11.6667 21.6667 11.6667H1.66667C0.746183 11.6667 0 10.9205 0 10Z"
                                       fill="currentcolor" />
                                 </svg>
                              </span>
                           </button>
                        </div>
                     </div>
                  </div>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>
   <!-- header-area-end -->

</header>





<?php get_template_part('template-parts/header/header-side-info'); ?>
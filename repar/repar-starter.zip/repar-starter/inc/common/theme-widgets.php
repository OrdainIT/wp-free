<?php 

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function repar_starter_widgets_init() {



    /**
     * blog sidebar
     */
    register_sidebar( [
        'name'          => esc_html__( 'Blog Sidebar', 'repar-starter' ),
        'id'            => 'blog-sidebar',
        'description'          => esc_html__( 'Set Your Blog Widget', 'repar-starter' ),
        'before_widget' => '<div id="%1$s" class="it-common-sidebar-widget it-blog-sidebar-search mb-55 %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="it-blog-sidebar-title mb-35">',
        'after_title'   => '</h4>',
    ] );
    /**
     * Shop sidebar
     */
    register_sidebar( [
        'name'          => esc_html__( 'Wocommerce Sidebar', 'repar-starter' ),
        'id'            => 'shop-sidebar',
        'description'          => esc_html__( 'Set Your Shop Widget', 'repar-starter' ),
        'before_widget' => '<div id="%1$s" class="it-common-sidebar-widget it-shop-widget  mb-35  %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="it-shop-widget-title">',
        'after_title'   => '</h3>',
    ] );


    $footer_widgets = get_theme_mod( 'footer_widget_number', 4 );

    // footer default
    for ( $num = 1; $num <= $footer_widgets; $num++ ) {
        register_sidebar( [
            'name'          => sprintf( esc_html__( 'Footer Style 1 : %1$s', 'repar-starter' ), $num ),
            'id'            => 'footer-'.$num,
            'description'   => sprintf( esc_html__( 'Footer column %1$s', 'repar-starter' ), $num ),
            'before_widget' => '<div id="%1$s" class="it-footer-widget %2$s it-footer-col-'.$num.'     %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h4 class="it-footer-widget-title">',
            'after_title'   => '</h4>',
        ] );
    }


 

 



}
add_action( 'widgets_init', 'repar_starter_widgets_init' );
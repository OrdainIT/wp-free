<?php
/**
 * Breadcrumbs for repar-starter theme.
 *
 * @package     repar-starter
 * @author      Ordainit
 * @copyright   Copyright (c) 2024, Ordainit
 * @link        https://ordainit.com
 * @since       repar-starter 1.0.0
 */

function repar_starter_breadcrumb_func() {
    global $post;
    $breadcrumb_class = '';
    $breadcrumb_show = 1;

    // Breadcrumb title logic
    if (is_front_page() && is_home()) {
        $title = get_theme_mod('breadcrumb_blog_title', __('Blog', 'repar-starter'));
        $breadcrumb_class = 'home_front_page';
    } elseif (is_front_page()) {
        $title = get_theme_mod('breadcrumb_blog_title', __('Blog', 'repar-starter'));
        $breadcrumb_show = 0;
    } elseif (is_home()) {
        if (get_option('page_for_posts')) {
            $title = get_the_title(get_option('page_for_posts'));
        }
    } elseif (is_single() && 'post' == get_post_type()) {
        $title = get_the_title();
    } elseif (is_single() && 'product' == get_post_type()) {
        $title = get_the_title(); // Get the product title dynamically
    } elseif (is_single() && 'courses' == get_post_type()) {
        $title = esc_html__('Course Details', 'repar-starter');
    } elseif (is_post_type_archive('courses')) {
        $title = esc_html__('Courses', 'repar-starter');
    } elseif (function_exists('is_product_category') && is_product_category()) {
        $title = single_term_title('', false); // Get the product category name
    } elseif (function_exists('is_product_tag') && is_product_tag()) {
        $title = single_term_title('', false); // Get the product tag name
    } elseif (is_search()) {
        $title = esc_html__('Search Results for: ', 'repar-starter') . get_search_query();
    } elseif (is_404()) {
        $title = esc_html__('Page not Found', 'repar-starter');
    } elseif (function_exists('is_woocommerce') && is_woocommerce()) {
        if (is_shop()) {
            $title = get_theme_mod('breadcrumb_shop', __('Shop', 'repar-starter'));
        }
    } elseif (is_archive()) {
        $title = get_the_archive_title();
    } else {
        $title = get_the_title();
    }

    // Get post/page/shop ID for breadcrumb custom field checks
    $_id = get_the_ID();
    if (is_single() && 'product' == get_post_type()) {
        $_id = $post->ID;
    } elseif (function_exists("is_shop") && is_shop()) {
        $_id = wc_get_page_id('shop');
    } elseif (is_home() && get_option('page_for_posts')) {
        $_id = get_option('page_for_posts');
    }

    // Check if breadcrumb is hidden using custom fields
    $is_breadcrumb = function_exists('get_field') ? get_field('hide_breadcrumb', $_id) : '';
    if (!empty($_GET['s'])) {
        $is_breadcrumb = null; // Show breadcrumb if it's a search
    }

    // Only show breadcrumb if not hidden
    if (empty($is_breadcrumb) && $breadcrumb_show == 1) {
        // Get background image
        $bg_img_from_page = function_exists('get_field') ? get_field('breadcrumb_bg', $_id) : '';
        $hide_bg_img = function_exists('get_field') ? get_field('hide_bg_image', $_id) : '';

        // Theme options
        $bg_img = get_theme_mod('breadcrumb_image');
        $repar_starter_breadcrumb_shape_switch = get_theme_mod('repar_starter_breadcrumb_shape_switch', false);
        $breadcrumb_switcher = get_theme_mod('breadcrumb_switcher', true);

        // Check to hide or show background image
        if ($hide_bg_img && empty($_GET['s'])) {
            $bg_img = '';
        } else {
            $bg_img = !empty($bg_img_from_page) ? $bg_img_from_page['url'] : $bg_img;
        }

        $breadcrumb_shap1 = get_theme_mod('breadcrumb_shap1', 'repar-starter');
        $breadcrumb_shap2 = get_theme_mod('breadcrumb_shap2', 'repar-starter');

        // Output breadcrumb HTML if the switcher is on
        if (!empty($breadcrumb_switcher)) { ?>
            <div class="it-breadcrumb-area fix it-breadcrumb-bg p-relative" data-background="<?php echo esc_url($bg_img); ?>">
                <?php if(!empty($repar_starter_breadcrumb_shape_switch)):?>
                <div class="it-breadcrumb-shape-1">
                    <img src="<?php echo esc_url($breadcrumb_shap1, 'repar-starter');?>" alt="">
                </div>
                <div class="it-breadcrumb-shape-2">
                    <img src="<?php echo esc_url($breadcrumb_shap2, 'repar-starter');?>" alt="">
                </div>
                <?php endif;?>
                <div class="container">
                    <div class="row ">
                    <div class="col-md-12">
                        <div class="it-breadcrumb-content z-index-3">
                            <div class="it-breadcrumb-title-box">
                                <h3 class="it-breadcrumb-title"><?php echo esc_html($title); ?></h3>
                            </div>
                            <div class="it-breadcrumb-list-wrap">
                                <div class="it-breadcrumb-list">
                                    <span><a href="<?php echo esc_url(home_url()); ?>"><?php echo esc_html__('Home', 'repar-starter'); ?></a></span>
                                    <span class="dvdr"><?php echo esc_html__('//', 'repar-starter'); ?></span>
                                    <span>
                                        <?php echo esc_html($title); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        <?php }
    }
}

add_action('repar_starter_before_main_content', 'repar_starter_breadcrumb_func');

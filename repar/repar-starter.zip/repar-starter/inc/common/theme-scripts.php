<?php

/**
 * repar_starter_scripts description
 * @return [type] [description]
 */
function repar_starter_scripts() {

    /**
     * all css files
    */

    wp_enqueue_style( 'repar-starter-fonts', repar_starter_fonts_url(), array(), null);


    
    // Enqueue normal styles
     wp_enqueue_style( 'bootstrap', repar_starter_THEME_CSS_DIR . 'bootstrap.min.css', array() );
    wp_enqueue_style( 'custom-animation', repar_starter_THEME_CSS_DIR . 'custom-animation.css', [] );
    wp_enqueue_style( 'font-awesome-pro', repar_starter_THEME_CSS_DIR . 'font-awesome-pro.css', [] );
    wp_enqueue_style( 'spacing', repar_starter_THEME_CSS_DIR . 'spacing.css', [] );
    wp_enqueue_style( 'theme-core', repar_starter_THEME_CSS_DIR . 'main.css', [], time() );
    wp_enqueue_style( 'theme-unit', repar_starter_THEME_CSS_DIR . 'theme-unit.css', [], time() );
    wp_enqueue_style( 'theme-custom', repar_starter_THEME_CSS_DIR . 'theme-custom.css', [] );
    wp_enqueue_style( 'theme-style', get_stylesheet_uri() );


    // all js
    wp_enqueue_script( 'bootstrap-bundle', repar_starter_THEME_JS_DIR . 'bootstrap.bundle.min.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'wow', repar_starter_THEME_JS_DIR . 'wow.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'repar-starter-main', repar_starter_THEME_JS_DIR . 'main.js', [ 'jquery' ], time(), true );


    




    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'repar_starter_scripts' );

/*
Register Fonts
 */
function repar_starter_fonts_url() {
    $font_url = '';

    /*
    Translators: If there are characters in your language that are not supported
    by chosen font(s), translate this to 'off'. Do not translate into your own language.
     */
    if ( 'off' !== _x( 'on', 'Google font: on or off', 'repar-starter' ) ) {
        $font_url = 'https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Inter:wght@100..900&display=swap" rel="stylesheet';
    }
    return $font_url;
}
<?php
/**
 * repar-starter customizer
 *
 * @package repar-starter
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

add_action(
    'init',
    function () {
if(class_exists('kirki')){

/**
 * Added Panels & Sections
 */

 //Add panel
    new \Kirki\Panel(
        'repar_starter_customizer',
        [
            'priority'    => 10,
            'title'       => esc_html__( 'Repar Starter Customizer', 'repar-starter' ),
        ]
    );

    /**
     * Customizer Section
     */
    //=========== General Settings ================ //
    new \Kirki\Section(
    'repar_starter_general_settngs',
        [
            'title'       => esc_html__( 'General Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );



    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'repar_starter_preloader',
            'label'       => esc_html__( 'Preloader On/Off', 'repar-starter' ),
            'section'     => 'repar_starter_general_settngs',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'repar_starter_backtotop',
            'label'       => esc_html__( 'Back To Top On/Off', 'repar-starter' ),
            'section'     => 'repar_starter_general_settngs',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );







    //=========== Theme Typography ================ //
    new \Kirki\Section(
        'repar_starter_typography',
            [
                'title'       => esc_html__( 'Theme Typography', 'repar-starter' ),
                'description' => esc_html__( '', 'repar-starter' ),
                'panel'       => 'repar_starter_customizer',
                'priority'    => 10,
            ]
        );

    new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_setting',
            'label'       => esc_html__( 'Body Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'inter',
                'variant'      => '400',
                'color'           => '#6a6d7a',
                'font-size'       => '16px',
                'line-height'     => '1.3',
            ],
        ]
    );



    new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h1',
            'label'       => esc_html__( 'H1 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => 'regular',
                'font-weight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '40px',
                'line-height'     => '1.2',
            ],
        ]
    );

    new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h2',
            'label'       => esc_html__( 'H2 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => 'regular',
                'font-weight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '32px',
                'line-height'     => '1.2',
            ],
        ]
    );

    new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h3',
            'label'       => esc_html__( 'H3 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => 'regular',
                'font-weight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '28px',
                'line-height'     => '1.2',
            ],
        ]
    );
    new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h4',
            'label'       => esc_html__( 'H4 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => 'regular',
                'font-weight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '24px',
                'line-height'     => '1.2',
            ],
        ]
    );
     new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h5',
            'label'       => esc_html__( 'H5 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => 'regular',
                'font-weight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '20px',
                'line-height'     => '1.2',
            ],
        ]
    );
     new \Kirki\Field\Typography(
        [
            'settings'    => 'repar_starter_typography_h6',
            'label'       => esc_html__( 'H6 Typography', 'repar-starter' ),
            'description' => esc_html__( 'The full set of options.', 'repar-starter' ),
            'section'     => 'repar_starter_typography',
            'priority'    => 10,
            'transport'   => 'auto',
            'default'     => [
                'font-family'     => 'Barlow Condensed',
                'variant'         => '700',
                'font-wight'      => '700',
                'color'           => '#00102f',
                'font-size'       => '16px',
                'line-height'     => '1.2',
            ],
        ]
    );

     //=========== Theme Color ================ //
    new \Kirki\Section(
        'repar_starter_theme_color',
            [
                'title'       => esc_html__( 'Theme Color', 'repar-starter' ),
                'description' => esc_html__( '', 'repar-starter' ),
                'panel'       => 'repar_starter_customizer',
                'priority'    => 10,
            ]
        );
    new \Kirki\Field\Color(
            [
                'settings'    => 'repar_starter_theme_pcolor',
                'label'       => __( 'Theme Color 1', 'repar-starter' ),
                'section'     => 'repar_starter_theme_color',
                'default'     => '#1B4CC3',
                'priority'    => 10,
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'  => ':root',
                        'property' => '--it-theme-1',
                    ],
                ],
            ]
        );
    new \Kirki\Field\Color(
            [
                'settings'    => 'repar_starter_theme_scolor',
                'label'       => __( 'Theme Color 2', 'repar-starter' ),
                'section'     => 'repar_starter_theme_color',
                'default'     => '#FF8A71',
                'priority'    => 10,
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'  => ':root',
                        'property' => '--it-theme-2',
                    ],
                ],
            ]
        );
    new \Kirki\Field\Color(
            [
                'settings'    => 'repar_starter_secoundary_scolor',
                'label'       => __( 'Theme Secoundary Color 1', 'repar-starter' ),
                'section'     => 'repar_starter_theme_color',
                'default'     => '#EF5D3C',
                'priority'    => 10,
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'  => ':root',
                        'property' => '--it-common-orange',
                    ],
                ],
            ]
        );
    new \Kirki\Field\Color(
            [
                'settings'    => 'repar_starter_secoundary_scolor1',
                'label'       => __( 'Theme Secoundary Color 2', 'repar-starter' ),
                'section'     => 'repar_starter_theme_color',
                'default'     => '#E22D03',
                'priority'    => 10,
                'transport'   => 'auto',
                'output'      => [
                    [
                        'element'  => ':root',
                        'property' => ' --it-common-orange-2',
                    ],
                ],
            ]
        );







    //=========== Header Top Info Settings ================ //
    new \Kirki\Section(
    'header_top_setting',
        [
            'title'       => esc_html__( 'Header Top Info Setting', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

    // Header Top Switch

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_top_switcher',
            'label'       => esc_html__( 'Topbar Switcher', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'section'     => 'header_top_setting',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_phone_number',
            'label'    => esc_html__( 'Phone Number', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( '(00)8757845682', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_email_id',
            'label'    => esc_html__( 'Email Addres', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'info@repar-starter.com', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_Working_hour',
            'label'    => esc_html__( 'Working Hour', 'repar-starter' ),
            'description' => esc_html__('This Field For Header 2', 'repar-starter'),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'Working : Monday -Friday.9:am - 5:Pm', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_Address',
            'label'    => esc_html__( 'Address', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'Moon ave, New York, 2020 NY US', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_Address_url',
            'label'    => esc_html__( 'Address URL', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'https://goo.gl/maps/qzqY2PAcQwUz1BYN9', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_ac_button',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 1', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'Login', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_ac_button_5',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 5', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'Login / Register', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_ac_button_url',
            'label'    => esc_html__( 'Button URL', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 1', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_button2',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 1', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( 'Help You', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_top_button2_url',
            'label'    => esc_html__( 'Button URL', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 1', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Textarea(
        [
            'settings' => 'header_top_higlist_text',
            'label'    => esc_html__( 'Highlist Text', 'repar-starter' ),
            'description'    => esc_html__( 'Only For Header Style 6', 'repar-starter' ),
            'section'  => 'header_top_setting',
            'default'  => repar_starter_kses( '<span>Keeping Your Vessel Afloat and Efficient! <a class="border-line-black"href="#">Contact Us <i class="fa-solid fa-arrow-right"></i></a> </span>', 'repar-starter' ),
            'priority' => 10,
        ]
    );

new \Kirki\Field\Repeater(
	[
		'settings' => 'header_top_slider',
		'label'    => esc_html__( 'Header Top slider', 'repar-starter' ),
		'section'  => 'header_top_setting',
		'priority' => 10,
		'default'  => [
			[
				'header_top_slider_text'   => esc_html__( 'wooden furniture', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'home renovation', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'hardwook work', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'wooden furniture', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'best quality products', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'hardwook work', 'repar-starter' ),
			],
			[
				'header_top_slider_text'   => esc_html__( 'home renovation', 'repar-starter' ),
			],
		],
		'fields'   => [
			'header_top_slider_text'   => [
				'type'        => 'text',
				'label'       => esc_html__( 'Title Text', 'repar-starter' ),
				'description' => esc_html__( 'Add Text here', 'repar-starter' ),
				'default'     => 'wooden furniture',
			],
			'header_top_slider_img'   => [
				'type'        => 'image',
				'label'       => esc_html__( 'Image', 'repar-starter' ),
				'description' => esc_html__( 'Add Image here', 'repar-starter' ),
				'default'     => get_template_directory_uri().'/assets/img/shape/header-star.png',
			],
            
		],
	]
);
 
   

     //=========== Header Socials ================ //

    new \Kirki\Section(
    'repar_starter_header_socials',
        [
            'title'       => esc_html__( 'Header Top Socials Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

      new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_social_switcher',
            'label'       => esc_html__( 'Header Social Swithcer', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'section'     => 'repar_starter_header_socials',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );

    new \Kirki\Field\Text(
        [
            'settings' => 'header_social_facebook_url',
            'label'    => esc_html__( 'Facebook URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_socials',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
      new \Kirki\Field\Text(
        [
            'settings' => 'header_social_instagram_url',
            'label'    => esc_html__( 'Instagram URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_socials',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'header_social_twitter_url',
            'label'    => esc_html__( 'Twitter URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_socials',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
      new \Kirki\Field\Text(
        [
            'settings' => 'header_social_linkedin_url',
            'label'    => esc_html__( 'LinkedIn URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_socials',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );

     //=========== Header Right ================ //

    new \Kirki\Section(
    'repar_starter_header_right_settings',
        [
            'title'       => esc_html__( 'Header Right Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );


  new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_right_switcher',
            'label'       => esc_html__( 'Header Right Swithcer', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'section'     => 'repar_starter_header_right_settings',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_right_icon_img',
            'label'       => esc_html__( 'Icon Image', 'repar-starter' ),
            'section'     => 'repar_starter_header_right_settings',
            'default'     =>get_template_directory_uri().'/assets/img/shape/header-icon.png',
        ]
    );
  new \Kirki\Field\Textarea(
        [
            'settings' => 'header_right_text_area',
            'label'    => esc_html__( 'Text Area', 'repar-starter' ),
            'section'  => 'repar_starter_header_right_settings',
            'default'  => repar_starter_kses( '<span>Emergency</span><a class="border-line-black" href="tel:+99012356987">(+99) 012356987</a>', 'repar-starter' ),
            'priority' => 10,
        ]
    );
      new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_right_btn_switcher',
            'label'       => esc_html__( 'Button Switcher', 'repar-starter' ),
            'section'     => 'repar_starter_header_right_settings',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
  new \Kirki\Field\Text(
        [
            'settings' => 'header_right_btn_text',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'section'  => 'repar_starter_header_right_settings',
            'default'  => esc_html__( 'Create An Account', 'repar-starter' ),
            'priority' => 10,
        ]
    );
  new \Kirki\Field\URL(
        [
            'settings' => 'header_right_btn_url',
            'label'    => esc_html__( 'Button URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_right_settings',
            'default'  => esc_html__('#', 'repar-starter'),
            'priority' => 10,
        ]
    );
  new \Kirki\Field\URL(
        [
            'settings' => 'header_right__icon_btn_url',
            'label'    => esc_html__( 'Icon URL', 'repar-starter' ),
            'description' => esc_html__('For Header Style 4', 'repar-starter'),
            'section'  => 'repar_starter_header_right_settings',
            'default'  => esc_html__('#', 'repar-starter'),
            'priority' => 10,
        ]
    );
  new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'header_right_search_icon_switcher',
            'label'       => esc_html__( 'Search Icon Switcher', 'repar-starter' ),
            'section'     => 'repar_starter_header_right_settings',
            'default'     => 'off',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
  new \Kirki\Field\Image(
    [
        'settings'    => 'header_right_search_logo',
        'label'       => esc_html__( 'Search Form Logo', 'repar-starter' ),
        'section'     => 'repar_starter_header_right_settings',
    ]
);

// Header Logo & Style Settings
    new \Kirki\Section(
    'repar_starter_header_logo',
        [
            'title'       => esc_html__( 'Header Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

    new \Kirki\Field\Select(
        [
            'settings'    => 'repar_starter_header_style',
            'label'       => esc_html__( 'Select Header Style', 'repar-starter' ),
            'section'     => 'repar_starter_header_logo',
            'default'     => 'header-style-11',
            'priority'    => 10,
            'multiple'    => 1,
            'choices'     => [
                'header-style-11' => esc_html__('Header Style 1', 'repar-starter'),
            ],
        ]
    );

    //Header Logo
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_logo',
            'label'       => esc_html__( 'Header Logo', 'repar-starter' ),
            'description' => esc_html__( 'Upload Your Logo Here', 'repar-starter' ),
            'section'     => 'repar_starter_header_logo',
            'default'     => get_template_directory_uri() . '/assets/img/logo/logo.png',
        ]
    );






// Header Logo & Style Settings
    new \Kirki\Section(
    'repar_starter_header_side_info',
        [
            'title'       => esc_html__( 'Header Side Info', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

      //Header Logo
    new \Kirki\Field\Image(
        [
            'settings'    => 'header_side_logo',
            'label'       => esc_html__( 'Header Side Info Logo', 'repar-starter' ),
            'description' => esc_html__( 'Upload Your Logo Here', 'repar-starter' ),
            'section'     => 'repar_starter_header_side_info',
            'default'     => get_template_directory_uri() . '/assets/img/logo/logo-white-5.png',
        ]
    );


 

    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_title',
            'label'    => esc_html__( 'Title', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( 'Get In Touch', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'side_info_description_switcher',
            'label'       => esc_html__( 'Descriptions Show/Hide', 'repar-starter' ),
            'section'     => 'repar_starter_header_side_info',
            'default'     => 'on',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
    new \Kirki\Field\Textarea(
        [
            'settings' => 'side_info_descriptions',
            'label'    => esc_html__( 'Descriptions', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( 'Suspendisse interdum consectetur libero id. Fermentum leo vel orci porta non. Euismod viverra nibh cras pulvinar suspen.', 'repar-starter' ),
            'priority' => 10,
        ]
    );

 


    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_phone',
            'label'    => esc_html__( 'Phone', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '(00)45611227890', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_location',
            'label'    => esc_html__( 'Address', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '238, Arimantab, Moska - USA.', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Url(
        [
            'settings' => 'side_info_location_url',
            'label'    => esc_html__( 'Address URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( 'htits://www.google.com/maps/@37.4801311,22.8928877,3z', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'side_info_social_switcher',
            'label'       => esc_html__( 'Social Icon Show/Hide', 'repar-starter' ),
            'section'     => 'repar_starter_header_side_info',
            'default'     => 'on',
            'choices'     => [
                'on'  => esc_html__( 'Enable', 'repar-starter' ),
                'off' => esc_html__( 'Disable', 'repar-starter' ),
            ],
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_twitter_url',
            'label'    => esc_html__( 'Twitter URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_instagram_url',
            'label'    => esc_html__( 'Instagram URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_facebook_url',
            'label'    => esc_html__( 'Facebook URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'side_info_dribbble_url',
            'label'    => esc_html__( 'Dribbble URL', 'repar-starter' ),
            'section'  => 'repar_starter_header_side_info',
            'default'  => esc_html__( '#', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    
    // BreadCrumb Settings
    new \Kirki\Section(
    'repar_starter_breadcrumb_settings',
        [
            'title'       => esc_html__( 'Breadcrumb Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

    new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'breadcrumb_switcher',
                'label'       => esc_html__( 'Breadcrumb On/Off', 'repar-starter' ),
                'section'     => 'repar_starter_breadcrumb_settings',
                'default'     => 'on',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'repar-starter' ),
                    'off' => esc_html__( 'Disable', 'repar-starter' ),
                ],
            ]
        );

    new \Kirki\Field\Image(
        [
            'settings'    => 'breadcrumb_image',
            'label'       => esc_html__( 'Breadcrumb Image', 'repar-starter' ),
            'description' => esc_html__( 'Upload Breadcrumb Image', 'repar-starter' ),
            'section'     => 'repar_starter_breadcrumb_settings',
            'default'      => get_template_directory_uri().'/assets/img/inner/breadcrumb/breadcrumb.jpg',
        ]
    );
    new \Kirki\Field\Checkbox_Switch(
        [
            'settings'    => 'repar_starter_breadcrumb_shape_switch',
            'label'       => esc_html__( 'Shap On/Off', 'repar-starter' ),
            'section'     => 'repar_starter_breadcrumb_settings',
            'default'     => 'on',
            'choices'     => [
                    'on'  => esc_html__( 'Enable', 'repar-starter' ),
                    'off' => esc_html__( 'Disable', 'repar-starter' ),
                ],
        ]
    );
    new \Kirki\Field\Image(
        [
            'settings'    => 'breadcrumb_shap1',
            'label'       => esc_html__( 'Breadcrumb Shap 1', 'repar-starter' ),
            'description' => esc_html__( 'Upload Breadcrumb Shap', 'repar-starter' ),
            'section'     => 'repar_starter_breadcrumb_settings',
            'default'      => get_template_directory_uri().'/assets/img/inner/breadcrumb/shape-1.png',
        ]
    );
    new \Kirki\Field\Image(
        [
            'settings'    => 'breadcrumb_shap2',
            'label'       => esc_html__( 'Breadcrumb Shap 2', 'repar-starter' ),
            'description' => esc_html__( 'Upload Breadcrumb Shap', 'repar-starter' ),
            'section'     => 'repar_starter_breadcrumb_settings',
            'default'      => get_template_directory_uri().'/assets/img/inner/breadcrumb/shape-2.png',
        ]
    );

     //Blog Settings
    new \Kirki\Section(
    'repar_starter_404_settings',
        [
            'title'       => esc_html__( '404 Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );

    new \Kirki\Field\Image(
        [
            'settings'    => '_image_404_setup',
            'label'       => esc_html__( 'Upload 404 Image', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'section'     => 'repar_starter_404_settings',
            'default'     => get_template_directory_uri() . '/assets/img/inner/error/thumb.png',
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'repar_starter_error_title',
            'label'    => esc_html__( 'Title One', 'repar-starter' ),
            'section'  => 'repar_starter_404_settings',
            'default'  => esc_html__( 'Sorry, Page Not Found!', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Textarea(
        [
            'settings' => 'repar_starter_error_desc',
            'label'    => esc_html__( 'Title Two', 'repar-starter' ),
            'section'  => 'repar_starter_404_settings',
            'default'  => repar_starter_kses( 'It looks like nothing was found at this location. Maybe try one of the <br>  links below or a search?.', 'repar-starter' ),
            'priority' => 10,
        ]
    );
    new \Kirki\Field\Text(
        [
            'settings' => 'repar_starter_error_link_text',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'section'  => 'repar_starter_404_settings',
            'default'  => esc_html__( 'Back to Home', 'repar-starter' ),
            'priority' => 10,
        ]
    );

    //Blog Settings
    new \Kirki\Section(
    'repar_starter_blog_settings',
        [
            'title'       => esc_html__( 'Blog Settings', 'repar-starter' ),
            'description' => esc_html__( '', 'repar-starter' ),
            'panel'       => 'repar_starter_customizer',
            'priority'    => 10,
        ]
    );
    new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'repar_starter_blog_author_switch',
                'label'       => esc_html__( 'Blog Author Meta On/Off', 'repar-starter' ),
                'section'     => 'repar_starter_blog_settings',
                'default'     => 'on',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'repar-starter' ),
                    'off' => esc_html__( 'Disable', 'repar-starter' ),
                ],
            ]
        );
    new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'repar_starter_blog_date_switch',
                'label'       => esc_html__( 'Blog Date Meta On/Off', 'repar-starter' ),
                'section'     => 'repar_starter_blog_settings',
                'default'     => 'on',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'repar-starter' ),
                    'off' => esc_html__( 'Disable', 'repar-starter' ),
                ],
            ]
        );

    new \Kirki\Field\Text(
        [
            'settings' => 'repar_starter_blog_btn',
            'label'    => esc_html__( 'Button Text', 'repar-starter' ),
            'section'  => 'repar_starter_blog_settings',
            'default'  => esc_html__( 'Read More', 'repar-starter' ),
            'priority' => 10,
        ]
    );

            new \Kirki\Field\Select(
                [
                    'settings'    => 'repar_starter_bolg_style',
                    'label'       => esc_html__('Select Blog Style', 'repar-starter'),
                    'section'     => 'repar_starter_blog_settings',
                    'default'     => 'blog-style-1',
                    'multiple'    => 1,
                    'choices'     => [
                        'blog-style-1' => esc_html__('Blog Style 1', 'repar-starter'),
                    ],
                ]
            );









    // Footer Settings
      new \Kirki\Section(
        'repar_starter_footer_settings',
            [
                'title'       => esc_html__( 'Footer Settings', 'repar-starter' ),
                'description' => esc_html__( '', 'repar-starter' ),
                'panel'       => 'repar_starter_customizer',
                'priority'    => 10,
            ]
        );

      new \Kirki\Field\Select(
            [
                'settings'    => 'repar_starter_default_footer',
                'label'       => esc_html__( 'Choose Footer Style', 'repar-starter' ),
                'section'     => 'repar_starter_footer_settings',
                'default'     => 'left',
                'priority'    => 10,
                'multiple'    => 1,
                'choices'     => [
                    'footer-style-1'   => esc_html__('Footer Style 1', 'repar-starter'),
                ],
                'default'     => 'footer-style-1',
            ]
        );

        new \Kirki\Field\Image(
            [
                'settings'    => 'repar_starter_footer_bg_image',
                'label'       => esc_html__( 'Footer Background Image', 'repar-starter' ),
                'description' => esc_html__( 'Upload Background Image.', 'repar-starter' ),
                'section'     => 'repar_starter_footer_settings',
                'default'      => "",
            ]
        );
    




    
    
  
 


        new \Kirki\Field\Checkbox_Switch(
            [
                'settings'    => 'repar_starter_footer_social_switcher',
                'label'       => esc_html__( 'Footer Social Show/Hide', 'repar-starter' ),
                'description'       => esc_html__( 'Footer Social Section For Only Footer Style 1', 'repar-starter' ),
                'section'     => 'repar_starter_footer_settings',
                'default'     => 'off',
                'choices'     => [
                    'on'  => esc_html__( 'Enable', 'repar-starter' ),
                    'off' => esc_html__( 'Disable', 'repar-starter' ),
                ],
            ]
        );

        new \Kirki\Field\Text(
            [
                'settings' => 'repar_starter_footer_facebook_url',
                'label'    => esc_html__( 'Faceboook URL', 'repar-starter' ),
                'section'  => 'repar_starter_footer_settings',
                'default'  => esc_html__( '#', 'repar-starter' ),
                'priority' => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings' => 'repar_starter_footer_pinterest_url',
                'label'    => esc_html__( 'Pinterest URL', 'repar-starter' ),
                'section'  => 'repar_starter_footer_settings',
                'default'  => esc_html__( '#', 'repar-starter' ),
                'priority' => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings' => 'repar_starter_footer_linkedin_url',
                'label'    => esc_html__( 'Linkedin URL', 'repar-starter' ),
                'section'  => 'repar_starter_footer_settings',
                'default'  => esc_html__( '#', 'repar-starter' ),
                'priority' => 10,
            ]
        );
        new \Kirki\Field\Text(
            [
                'settings' => 'repar_starter_footer_youtube_url',
                'label'    => esc_html__( 'Youtube URL', 'repar-starter' ),
                'section'  => 'repar_starter_footer_settings',
                'default'  => esc_html__( '#', 'repar-starter' ),
                'priority' => 10,
            ]
        );


      
   
  




};



});
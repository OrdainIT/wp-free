(function ($) {
  "use strict";

  var windowOn = $(window);
  ///////////////////////////////////////////////////
  // 01. PreLoader Js
  windowOn.on("load", function () {
    $("#loading").fadeOut(500);
  });

  ///////////////////////////////////////////////////
  // 03. scroll-to-target
  windowOn.on("scroll", function () {
    var scroll = windowOn.scrollTop();
    if (scroll < 500) {
      $(".scroll-to-target").removeClass("open");
    } else {
      $(".scroll-to-target").addClass("open");
    }
  });

  ///////////////////////////////////////////////////
  // 04. Scroll Up Js
  if ($(".scroll-to-target").length) {
    $(".scroll-to-target").on("click", function () {
      var target = $(this).attr("data-target");
      // animate
      $("html, body").animate(
        {
          scrollTop: $(target).offset().top,
        },
        1000
      );
    });
  }

  ///////////////////////////////////////////////////
  // 05. wow animation
  var wow = new WOW({
    mobile: true,
  });
  wow.init();
  var windowOn = $(window);

 

  ///////////////////////////////////////////////////
  // 07. Sticky Header Js
  $(window).on("load", function () {
    $("#preloader").delay(350).fadeOut("slow");

    $("body").delay(350).css({ overflow: "visible" });
  });

  ////////////////////////////////////////////////////
  // 09. Sidebar Js
  $(".it-menu-bar").on("click focus", function () {
    $(".itoffcanvas").addClass("opened");
    $(".body-overlay").addClass("apply");
  });
  $(".close-btn").on("click", function () {
    $(".itoffcanvas").removeClass("opened");
    $(".body-overlay").removeClass("apply");
  });
  $(".body-overlay").on("click focus", function () {
    $(".itoffcanvas").removeClass("opened");
    $(".body-overlay").removeClass("apply");
  });

  

  ///////////////////////////////////////////////////
  // for header language
  if ($("#it-header-lang-toggle").length > 0) {
    window.addEventListener("click", function (e) {
      if (document.getElementById("it-header-lang-toggle").contains(e.target)) {
        $(".it-lang-list").toggleClass("it-lang-list-open");
      } else {
        $(".it-lang-list").removeClass("it-lang-list-open");
      }
    });
  }

  // for header
  if ($("#it-header-top__area-toogle").length > 0) {
    window.addEventListener("click", function (e) {
      if (
        document.getElementById("it-header-top__area-toogle").contains(e.target)
      ) {
        $(".it-header-top__area").toggleClass("open");
      } else {
        $(".it-header-top__area").removeClass("open");
      }
    });
  }

  // for header
  if ($("#it-header-top__category-toogle").length > 0) {
    window.addEventListener("click", function (e) {
      if (
        document
          .getElementById("it-header-top__category-toogle")
          .contains(e.target)
      ) {
        $(".it-header-top__category").toggleClass("open");
      } else {
        $(".it-header-top__category").removeClass("open");
      }
    });
  }

  $(".it-category-menu-toggle").on("click", function () {
    $(".it-category-menu > nav > ul").slideToggle();
  });

  ////////////////////////////////////////////////////
  // 16. Cart Quantity Js
  $(".cart-minus").on("click", function () {
    var $input = $(this).parent().find("input");
    var count = parseInt($input.val()) - 1;
    count = count < 1 ? 1 : count;
    $input.val(count);
    $input.change();
    return false;
  });

  $(".cart-plus").on("click", function () {
    var $input = $(this).parent().find("input");
    $input.val(parseInt($input.val()) + 1);
    $input.change();
    return false;
  });

  if ($(".subscribe-popup").length) {
    const loginPopup = document.querySelector(".subscribe-popup");
    const close = document.querySelector(".close");

    window.addEventListener("load", function () {
      showPopup();
    });

    function showPopup() {
      const timeLimit = 5;
      let i = 0;
      const timer = setInterval(function () {
        i++;
        if (i == timeLimit) {
          clearInterval(timer);
          loginPopup.classList.add("show");
        }
        console.log(i);
      }, 500);
    }

    close.addEventListener("click", function () {
      loginPopup.classList.remove("show");
    });
  }

  // 20. Show Login Toggle Js
  $("#showlogin").on("click", function () {
    $("#checkout-login").slideToggle(900);
  });

  $("#cbox").on("click", function () {
    $("#cbox_info").slideToggle(900);
  });

  $("#showcoupon").on("click", function () {
    $("#checkout_coupon").slideToggle(900);
  });

 

  ////////////////////////////////////////////////////
  // 03. Search Js
  $(".search-open-btn").on("click", function () {
    $(".search__popup").addClass("search-opened");
  });

  $(".search-close-btn").on("click", function () {
    $(".search__popup").removeClass("search-opened");
  });

  if ($(".it-menu-content").length && $(".it-menu-mobile").length) {
    let navContent = document.querySelector(".it-menu-content").outerHTML;
    let mobileNavContainer = document.querySelector(".it-menu-mobile");
    mobileNavContainer.innerHTML = navContent;

    let arrow = $(".it-menu-mobile .has-dropdown > a");

    arrow.each(function () {
      let self = $(this);
      let arrowBtn = document.createElement("BUTTON");
      arrowBtn.classList.add("dropdown-toggle-btn");
      arrowBtn.innerHTML = "<i class='fal fa-angle-right'></i>";

      self.append(function () {
        return arrowBtn;
      });

      self.find("button").on("click", function (e) {
        e.preventDefault();
        let self = $(this);
        self.toggleClass("dropdown-opened");
        self.parent().toggleClass("expanded");
        self
          .parent()
          .parent()
          .addClass("dropdown-opened")
          .siblings()
          .removeClass("dropdown-opened");
        self.parent().parent().children(".it-submenu").slideToggle();
      });
    });
  }

  ///////////////////////////////////////////////////
  // 07. Sticky Header Js
  windowOn.on("scroll", function () {
    var scroll = windowOn.scrollTop();
    if (scroll < 400) {
      $("#header-sticky").removeClass("header-sticky");
    } else {
      $("#header-sticky").addClass("header-sticky");
    }
  });

  if ($(".it-header-height").length > 0) {
    var headerHeight = document.querySelector(".it-header-height");
    var setHeaderHeight = headerHeight.offsetHeight;
    $(".it-header-height").each(function () {
      $(this).css({
        height: setHeaderHeight + "px",
      });
    });

    $(".it-header-height.header-sticky").each(function () {
      $(this).css({
        height: inherit,
      });
    });
  }

  //One Page Scroll Js
  function scrollNav() {
    $(".it-onepage-menu li").click(function () {
      $(".it-onepage-menu li.active").removeClass("active");
      $(this).addClass("active");

      $("html, body")
        .stop()
        .animate(
          {
            scrollTop: $($(this).attr("href")).offset().top - 80,
          },
          300
        );
      return false;
    });
  }
  scrollNav();

  if (
    $(".it-category-menu-content").length &&
    $(".it-category-mobile-menu").length
  ) {
    let navContent = document.querySelector(
      ".it-category-menu-content"
    ).outerHTML;
    let mobileNavContainer = document.querySelector(".it-category-mobile-menu");
    mobileNavContainer.innerHTML = navContent;

    $(".it-offcanvas-category-toggle").on("click", function () {
      $(this).siblings().find("nav").slideToggle();
    });

    let arrow = $(".it-category-mobile-menu .has-dropdown > a");

    arrow.each(function () {
      let self = $(this);
      let arrowBtn = document.createElement("BUTTON");
      arrowBtn.classList.add("dropdown-toggle-btn");
      arrowBtn.innerHTML = "<i class='fa-regular fa-angle-right'></i>";

      self.append(function () {
        return arrowBtn;
      });
      self.find("button").on("click", function (e) {
        e.preventDefault();
        let self = $(this);
        self.toggleClass("dropdown-opened");
        self.parent().toggleClass("expanded");
        self
          .parent()
          .parent()
          .addClass("dropdown-opened")
          .siblings()
          .removeClass("dropdown-opened");
        self.parent().parent().children(".it-submenu").slideToggle();
      });
    });
  }
})(jQuery);

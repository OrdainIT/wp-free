<?php

/**
 * repar-starter functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package repar-starter
 */

if ( !function_exists( 'repar_starter_setup' ) ):
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     *
     * Note that this function is hooked into the after_setup_theme hook, which
     * runs before the init hook. The init hook is too late for some features, such
     * as indicating support for post thumbnails.
     */
    function repar_starter_setup() {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         * If you're building a theme based on repar-starter, use a find and replace
         * to change 'repar-starter' to the name of your theme in all the template files.
         */
        load_theme_textdomain( 'repar-starter', get_template_directory() . '/languages' );

        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );
         add_theme_support( 'woocommerce' );
         add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-lightbox' );
        add_theme_support( 'wc-product-gallery-slider' );


        /*
         * Let WordPress manage the document title.
         * By adding theme support, we declare that this theme does not use a
         * hard-coded <title> tag in the document head, and expect WordPress to
         * provide it for us.
         */
        add_theme_support( 'title-tag' );

        /*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
         */
        add_theme_support( 'post-thumbnails' );

        // This theme uses wp_nav_menu() in one location.
        register_nav_menus(  array(
            'main-menu' => esc_html__( 'Primary Menu', 'repar-starter' ),
           
        ) );
        /*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support( 'html5', [
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ] );

        // Set up the WordPress core custom background feature.
        add_theme_support( 'custom-background', apply_filters( 'repar_starter_custom_background_args', [
            'default-color' => 'ffffff',
            'default-image' => '',
        ] ) );

        // Add theme support for selective refresh for widgets.
        add_theme_support( 'customize-selective-refresh-widgets' );

        //Enable custom header
        add_theme_support( 'custom-header' );

        /**
         * Add support for core custom logo.
         *
         * @link https://codex.wordpress.org/Theme_Logo
         */
        add_theme_support( 'custom-logo', [
            'height'      => 250,
            'width'       => 250,
            'flex-width'  => true,
            'flex-height' => true,
        ] );

        /**
         * Enable suporrt for Post Formats
         *
         * see: https://codex.wordpress.org/Post_Formats
         */
        add_theme_support( 'post-formats', [
            'image',
            'audio',
            'video',
            'gallery',
            'quote',
        ] );

        // Add support for Block Styles.
        add_theme_support( 'wp-block-styles' );
        add_editor_style('');

        // Add support for full and wide align images.
        add_theme_support( 'align-wide' );

        // Add support for editor styles.
        add_theme_support( 'editor-styles' );

        // Add support for responsive embedded content.
        add_theme_support( 'responsive-embeds' );

        remove_theme_support( 'widgets-block-editor' );

        add_image_size( 'repar-starter-case-details', 1170, 600, [ 'center', 'center' ] );
      
    }
endif;
add_action( 'after_setup_theme', 'repar_starter_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function repar_starter_content_width() {
    // This variable is intended to be overruled from themes.
    // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    $GLOBALS['content_width'] = apply_filters( 'repar_starter_content_width', 640 );
}
add_action( 'after_setup_theme', 'repar_starter_content_width', 0 );

if ( function_exists( 'register_block_style' ) ) {
    register_block_style(
        'core/quote',
        array(
            'name'         => 'blue-quote',
            'label'        => __( 'Blue Quote', 'repar-starter' ),
            'is_default'   => true,
            'inline_style' => '.wp-block-quote.is-style-blue-quote { color: blue; }',
        )
    );
}

function repar_starter_block_patterns() {
    // Check if the function exists to ensure compatibility.
    if ( function_exists( 'register_block_pattern' ) ) {
        // Register the block pattern.
        register_block_pattern(
            'my-theme/my-awesome-pattern', // Unique pattern name.
            array(
                'title'       => __( 'My Awesome Pattern', 'repar-starter' ),
                'description' => _x( 'A custom block pattern for awesome content.', 'Block pattern description', 'repar-starter' ),
                'content'     => '
                    <!-- wp:paragraph -->
                    <p>' . __( 'This is an example paragraph block in my custom pattern.', 'repar-starter' ) . '</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:image -->
                    <figure class="wp-block-image"><img src="' . esc_url( get_template_directory_uri() . '/images/example.jpg' ) . '" alt="' . esc_attr__( 'Example image', 'repar-starter' ) . '"/></figure>
                    <!-- /wp:image -->

                    <!-- wp:heading {"level":3} -->
                    <h3>' . __( 'Example Heading', 'repar-starter' ) . '</h3>
                    <!-- /wp:heading -->

                    <!-- wp:list -->
                    <ul><li>' . __( 'First item', 'repar-starter' ) . '</li><li>' . __( 'Second item', 'repar-starter' ) . '</li></ul>
                    <!-- /wp:list -->
                ',
                'categories'  => array( 'my-category' ),
                'keywords'    => array( 'custom', 'example' ),
            )
        );
    }
}
add_action( 'init', 'repar_starter_block_patterns' );




/**
 * Enqueue scripts and styles.
 */

define( 'repar_starter_THEME_DIR', get_template_directory() );
define( 'repar_starter_THEME_URI', get_template_directory_uri() );
define( 'repar_starter_THEME_CSS_DIR', repar_starter_THEME_URI . '/assets/css/' );
define( 'repar_starter_THEME_JS_DIR', repar_starter_THEME_URI . '/assets/js/' );
define( 'repar_starter_THEME_INC', repar_starter_THEME_DIR . '/inc/' );



// wp_body_open
if ( !function_exists( 'wp_body_open' ) ) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}
//body class
function repar_starter_custom_body_class($classes) {
    $classes[] = 'it-magic-cursor';
    return $classes;
}

add_filter('body_class', 'repar_starter_custom_body_class');

add_filter( 'body_class', 'repar_starter_add_class_when_menu_active' );
function repar_starter_add_class_when_menu_active( $classes ) {

    if (has_nav_menu('main-menu'))
      $classes[] = 'active_menu_class';

    return $classes;
}

/**
 * Implement the Custom Header feature.
 */
require repar_starter_THEME_INC . 'custom-header.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require repar_starter_THEME_INC . 'template-functions.php';

/**
 * Custom template helper function for this theme.
 */
require repar_starter_THEME_INC . 'template-helper.php';

/**
 * initialize repar-starter customizer class.
 */
include_once repar_starter_THEME_INC . 'theme-customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
    require repar_starter_THEME_INC . 'jetpack.php';
}



/**
 * include repar-starter functions file
 */
require_once repar_starter_THEME_INC . 'class-navwalker.php';
require_once repar_starter_THEME_INC . '/common/theme-breadcrumb.php';
require_once repar_starter_THEME_INC . '/common/theme-scripts.php';
require_once repar_starter_THEME_INC . '/common/theme-widgets.php';

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function repar_starter_pingback_header() {
    if ( is_singular() && pings_open() ) {
        printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
    }
}
add_action( 'wp_head', 'repar_starter_pingback_header' );




// repar_starter_comment 
if ( !function_exists( 'repar_starter_comment' ) ) {
    function repar_starter_comment( $comment, $args, $depth ) {
        $GLOBAL['comment'] = $comment;
        extract( $args, EXTR_SKIP );
        $args['reply_text'] = 'Reply';
        $replayClass = 'comment-depth-' . esc_attr( $depth );
        ?>
            <li id="comment-<?php comment_ID();?>">
                <div class="postbox-comment-user p-relative d-flex align-items-start">
                    <div class="postbox-user-thumb">
                       <?php 
                        $avatar_url = get_avatar_url( $comment, [ 'size' => 102 ] );
                        if ( !empty( $avatar_url ) ): ?>
                            <img src="<?php echo esc_url( $avatar_url ); ?>" alt="">
                        <?php else: ?>
                            <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/avatar/avata-3.png' ); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="postbox-user-info">
                        <h4 class="user-title"><?php print get_comment_author_link();?> </h4>
                        <span><?php comment_time( get_option( 'date_format' ) );?></span>
                        <p><?php comment_text();?></p>
                    </div>
                     <?php 
                        comment_reply_link( array_merge( $args, [ 
                            'depth' => $depth, 
                            'max_depth' => $args['max_depth'],
                            'reply_text' => '<svg width="20" height="14" viewBox="0 0 20 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M19.0005 13.7501C19.1255 13.7501 19.2505 13.7191 19.3645 13.6561C19.6695 13.4871 19.8175 13.1291 19.7205 12.7941C19.3085 11.3531 18.4165 9.25605 16.5155 7.45605C13.4515 4.55405 9.67747 4.19405 7.74947 4.23805V1.00105C7.74947 0.698053 7.56647 0.424053 7.28648 0.308053C7.00648 0.192053 6.68347 0.256053 6.46947 0.471053L0.469475 6.47105C0.176476 6.76405 0.176476 7.23905 0.469475 7.53205L6.46947 13.5321C6.68447 13.7471 7.00648 13.8121 7.28648 13.6951C7.56647 13.5791 7.74947 13.3051 7.74947 13.0021V9.70105C9.12547 9.46905 10.5045 9.47905 11.8585 9.73905C15.1995 10.3791 17.4185 12.3731 18.4435 13.5061C18.5895 13.6681 18.7935 13.7531 18.9995 13.7531L19.0005 13.7501ZM9.71047 8.03205C8.75447 8.03205 7.79448 8.13805 6.83848 8.34905C6.49448 8.42505 6.25047 8.72905 6.25047 9.08105V11.1881L2.06148 6.99905L6.25047 2.81005V5.02605C6.25047 5.23605 6.33948 5.43805 6.49448 5.58005C6.64948 5.72305 6.85948 5.79305 7.06748 5.77305C8.24248 5.66705 12.3285 5.55605 15.4845 8.54405C16.0525 9.08205 16.5165 9.65105 16.8975 10.2171C15.6485 9.39105 14.0595 8.63005 12.1405 8.26205C11.3365 8.10805 10.5255 8.03105 9.70947 8.03105L9.71047 8.03205Z" fill="#076CEC"></path>
                                        </svg>'  // Custom reply text
                                                    ] ) ); 
                    ?>
                </div>
             </li>
        <?php
    }
}


/**
 * shortcode supports for removing extra p, spance etc
 *
 */
add_filter( 'the_content', 'repar_starter_shortcode_extra_content_remove' );
/**
 * Filters the content to remove any extra paragraph or break tags
 * caused by shortcodes.
 *
 * @since 1.0.0
 *
 * @param string $content  String of HTML content.
 * @return string $content Amended string of HTML content.
 */
function repar_starter_shortcode_extra_content_remove( $content ) {

    $array = [
        '<p>['    => '[',
        ']</p>'   => ']',
        ']<br />' => ']',
    ];
    return strtr( $content, $array );

}



// repar_starter_search_filter_form
if ( !function_exists( 'repar_starter_search_filter_form' ) ) {
    function repar_starter_search_filter_form( $form ) {

        $form = sprintf(
            ' <div class="sidebar-search-box p-relative">
                    <form  action="%s" method="get">
                        <div class="sidebar-search-input">
                        <input type="text"  value="%s" required name="s" placeholder="%s">
                        </div>
                        <div class="sidebar-search-button">
                            <button type="submit">
                                <i class="fal fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>
           ',
            esc_url( home_url( '/' ) ),
            esc_attr( get_search_query() ),
            esc_html__( 'Search', 'repar-starter' )
        );

        return $form;
    }
    add_filter( 'get_search_form', 'repar_starter_search_filter_form' );
}

add_action( 'admin_enqueue_scripts', 'repar_starter_admin_custom_scripts' );

function repar_starter_admin_custom_scripts() {
    wp_enqueue_media();
    wp_enqueue_style( 'customizer-style', get_template_directory_uri() . '/inc/css/customizer-style.css',array());
    wp_register_script( 'repar-starter-admin-custom', get_template_directory_uri() . '/inc/js/admin_custom.js', [ 'jquery' ], '', true );
    wp_enqueue_script( 'repar-starter-admin-custom' );
}




<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package repar-starter
 */

get_header();

               $_image_404_setup = get_theme_mod('_image_404_setup',get_template_directory_uri() . '/assets/img/inner/error/thumb.png');
               $repar_starter_error_title = get_theme_mod('repar_starter_error_title', __('Sorry, Page Not Found!', 'repar-starter'));
               $repar_starter_error_link_text = get_theme_mod('repar_starter_error_link_text', __('Back to Home', 'repar-starter'));
               $repar_starter_error_desc = get_theme_mod('repar_starter_error_desc', repar_starter_kses('It looks like nothing was found at this location. Maybe try one of the <br>  links below or a search?.', 'repar-starter'));
?>

<div class="it-error-area pt-120 pb-120">
      <div class="container">
         <div class="row align-items-center">
            <div class="col-12">
               <div class="it-error-content text-center wow itfadeUp" data-wow-duration=".9s" data-wow-delay=".3s">
                  <div class="it-error-thumb">
                     <img src="<?php echo esc_url($_image_404_setup);?>" alt="">
                  </div>
                  <h5 class="it-error-title"><?php echo esc_html($repar_starter_error_title);?></h5>
                  <p><?php echo repar_starter_kses($repar_starter_error_desc);?></p>
                  <a class="it-btn orange-bg" href="<?php echo esc_url(home_url());?>">
                     <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M0.969669 6.53033C0.676777 6.23744 0.676777 5.76256 0.969669 5.46967L5.74264 0.696699C6.03553 0.403806 6.51041 0.403806 6.8033 0.696699C7.09619 0.989593 7.09619 1.46447 6.8033 1.75736L2.56066 6L6.8033 10.2426C7.09619 10.5355 7.09619 11.0104 6.8033 11.3033C6.51041 11.5962 6.03553 11.5962 5.74264 11.3033L0.969669 6.53033ZM25.5 6.75H1.5V5.25H25.5V6.75Z" fill="currentcolor"></path>
                      </svg>
                      <?php echo esc_html($repar_starter_error_link_text);?>
                  </a>
               </div>
            </div>
         </div>
      </div>
     </div>

 
      

<?php
get_footer();

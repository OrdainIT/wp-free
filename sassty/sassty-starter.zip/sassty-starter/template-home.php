<?php

/**
 * Template Name: Home Template
 * Description: A custom page template for Home layouts.
 */

$sassty_starter_hero_title = get_theme_mod('sassty_starter_hero_title', 'Successful Businesses Begin with Organized Finances.');
$sassty_starter_hero_subtitle = get_theme_mod('sassty_starter_hero_subtitle', 'Welcome Our SaasTech');

$sassty_starter_hero_description = get_theme_mod('sassty_starter_hero_description', 'Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.');
$sassty_starter_hero_button_text = get_theme_mod('sassty_starter_hero_button_text', 'Get Started');
$sassty_starter_hero_button_link = get_theme_mod('sassty_starter_hero_button_link', '#');
$sassty_starter_hero_image = get_theme_mod('sassty_starter_hero_image');
$sassty_starter_hero_shape = get_theme_mod('sassty_starter_hero_shape');
$sassty_starter_hero_shape_2 = get_theme_mod('sassty_starter_hero_shape_2');
$sassty_starter_hero_shape_3 = get_theme_mod('sassty_starter_hero_shape_3');


$sassty_starter_feature_title = get_theme_mod('sassty_starter_feature_title', 'Explore our features');
$sassty_starter_feature_description = get_theme_mod('sassty_starter_feature_description', 'we are self service sales data analytics software that lets you create visually <br> appealing data visualizations and insightful dashboard in minutes.');
$sassty_starter_feature_list = get_theme_mod('sassty_starter_feature_list');

$sassty_starter_about_title = get_theme_mod('sassty_starter_about_title', 'About Us');
$sassty_starter_about_description = get_theme_mod('sassty_starter_about_description', 'we are self service sales data analytics software that lets you create visually <br> appealing data visualizations and insightful dashboard in minutes.');
$sassty_starter_about_image = get_theme_mod('sassty_starter_about_image');
$sassty_starter_about_image_2 = get_theme_mod('sassty_starter_about_image_2');
$sassty_starter_about_image_3 = get_theme_mod('sassty_starter_about_image_3');
$sassty_starter_about_shape = get_theme_mod('sassty_starter_about_shape');
$sassty_about_faqs = get_theme_mod('sassty_about_faqs');


$sassty_starter_testi_section_title = get_theme_mod('sassty_starter_testi_section_title', 'What our clients say?');
$sassty_starter_testi_section_desc = get_theme_mod('sassty_starter_testi_section_desc', 'Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.');
$testimonial_thumbnail_image = get_theme_mod('testimonial_thumbnail_image');
$testimonial_thumbnail_shape = get_theme_mod('testimonial_thumbnail_shape');
$testimonial_thumbnail_shape2 = get_theme_mod('testimonial_thumbnail_shape2');
$testimonial_thumbnail_shape3 = get_theme_mod('testimonial_thumbnail_shape3');
$testimonial_thumbnail_shape4 = get_theme_mod('testimonial_thumbnail_shape4');
$sassty_starter_testimonial_list = get_theme_mod('sassty_starter_testimonial_list');

$sassty_starter_blog_section_title = get_theme_mod('sassty_starter_blog_section_title', 'Latest Release News & Articles');

$sassty_starter_blog_section_description = get_theme_mod('sassty_starter_blog_section_description', 'It is a long established fact that a reader will be distracted <br> by the readable content of a page.');

$sassty_starter_blog_section_button_text = get_theme_mod('sassty_starter_blog_section_button_text', 'View All Blog');

$sassty_starter_blog_section_button_link = get_theme_mod('sassty_starter_blog_section_button_link', '#');




get_header(); ?>



<!-- hero-area-start -->
<div class="it-hero-area p-relative it-hero-ptb">
   <img class="it-hero-shape-1 d-none d-xl-block" src="<?php echo esc_url($sassty_starter_hero_shape_2, 'sassty-starter'); ?>" alt="">
   <img class="it-hero-shape-3" src="<?php echo esc_url($sassty_starter_hero_shape_3, 'sassty-starter'); ?>" alt="">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-xxl-7 col-xl-6 col-lg-6">
            <div class="it-hero-content">
               <span class="it-hero-subtitle">
                  <?php echo esc_html($sassty_starter_hero_subtitle, 'sassty-starter'); ?>
               </span>
               <h1 class="it-hero-title it-split-text it-split-in-right"><?php echo esc_html($sassty_starter_hero_title, 'sassty-starter'); ?></h1>
               <div class="it-hero-text it-text-anim">
                  <p class="mb-35"><?php echo sassty_starter_kses($sassty_starter_hero_description, 'sassty-starter'); ?></p>
                  <div class="it-hero-button flex-nowrap d-sm-flex align-items-center it-fade-anim" data-fade-from="left" data-delay=".9">
                     <a href="<?php echo esc_url($sassty_starter_hero_button_link, 'sassty-starter'); ?>" class="it-btn mr-30">
                        <?php echo esc_html($sassty_starter_hero_button_text, 'sassty-starter'); ?>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="col-xxl-5 col-xl-6 col-lg-6 it-fade-anim" data-fade-from="right" data-delay=".5" data-ease="bounce">
            <div class="it-hero-thumb p-relative">
               <img src="<?php echo esc_url($sassty_starter_hero_image, 'sassty-starter'); ?>" alt="">
               <div class="it-hero-thumb-shape-1">
                  <img src="<?php echo esc_url($sassty_starter_hero_shape, 'sassty-starter'); ?>" alt="">
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- hero-area-end -->

<!-- faq-area-start -->
<div class="it-faq-area p-relative z-index-1 pt-120 pb-120 gray-bg">
   <div class="it-faq-shape-1">
      <img src="<?php echo esc_url($sassty_starter_about_shape, 'sassty-starter'); ?>" alt="">
   </div>
   <div class="container">
      <div class="row align-items-center">
         <div class="col-xl-7 col-lg-6 it-fade-anim" data-fade-from="left" data-delay=".5">
            <div class="it-faq-left-box ">
               <div class="it-faq-thumb-box d-flex align-items-center justify-content-between">
                  <div class="it-faq-thumb mr-30">
                     <img src="<?php echo esc_url($sassty_starter_about_image, 'sassty-starter'); ?>" alt="">
                  </div>
                  <div class="it-faq-thumb">
                     <img src="<?php echo esc_url($sassty_starter_about_image_2, 'sassty-starter'); ?>" alt="">
                  </div>
               </div>
               <div class="it-faq-thumb-2">
                  <img src="<?php echo esc_url($sassty_starter_about_image_3, 'sassty-starter'); ?>" alt="">
               </div>
            </div>
         </div>
         <div class="col-xl-5 col-lg-6">
            <div class="it-faq-right-box">
               <div class="it-section-title-box it-text-anim mb-45">
                  <h4 class="it-section-title mb-15 it-split-text it-split-in-right"><?php echo sassty_starter_kses($sassty_starter_about_title, 'sassty-starter'); ?></h4>
                  <p><?php echo sassty_starter_kses($sassty_starter_about_description, 'sassty-starter'); ?></p>
               </div>
               <div class="it-custom-accordion">
                  <div class="accordion" id="accordionExample">
                     <?php $i = 0;
                     if (!empty($sassty_about_faqs) && is_array($sassty_about_faqs)): 
                     foreach ($sassty_about_faqs as $single_faq): $i++; ?>
                        <div class="accordion-items it-fade-anim" data-delay=".3">
                           <h2 class="accordion-header <?php echo $i === 1 ? "active" : ""; ?>" id="headingOne<?php echo esc_attr($i); ?>">
                              <button class="accordion-buttons " type="button" data-bs-toggle="collapse"
                                 data-bs-target="#collapseOne<?php echo esc_attr($i); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo esc_attr($i); ?>">
                                 <?php echo esc_html($single_faq['sassty_about_faq_title'], 'sassty-starter'); ?>
                              </button>
                           </h2>
                           <div id="collapseOne<?php echo esc_attr($i); ?>" class="accordion-collapse collapse <?php echo $i === 1 ? "show" : ""; ?> "
                              aria-labelledby="headingOne<?php echo esc_attr($i); ?>" data-bs-parent="#accordionExample">
                              <div class="accordion-body d-flex align-items-center">
                                 <p class="mb-0"><?php echo sassty_starter_kses($single_faq['sassty_about_faq_description'], 'sassty-starter'); ?></p>
                              </div>
                           </div>
                        </div>
                     <?php endforeach; endif; ?>



                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- faq-area-end -->

<!-- feature-area-start -->
<div class="it-feature-area pt-110 pb-120">
   <div class="container">
      <div class="row">
         <div class="col-xl-12">
            <div class="it-section-title-box text-center mb-65 it-text-anim">
               <h4 class="it-section-title it-split-text it-split-in-right mb-15"><?php echo esc_html($sassty_starter_feature_title, 'sassty-starter'); ?></h4>
               <p><?php echo sassty_starter_kses($sassty_starter_feature_description, 'sassty-starter'); ?></p>
            </div>
         </div>
      </div>
      <div class="row gx-35">
         <?php
         if (!empty($sassty_starter_feature_list) && is_array($sassty_starter_feature_list)):  
         foreach ($sassty_starter_feature_list as $single_feature_list):
          ?>
            <div class="col-xxl-3 col-xl-4 col-lg-4 col-md-6 mb-30 it-fade-anim" data-fade-from="bottom" data-delay=".3">
               <div class="it-feature-item text-center">
                  <div class="it-feature-icon mb-25">
                     <img src="<?php echo esc_url($single_feature_list['sassty_feature_image'], 'sassty-starter'); ?>" alt="">
                  </div>
                  <h4 class="it-feature-title mb-20"><a class="border-line-black" href="<?php echo esc_url($single_feature_list['sassty_feature_url'], 'sassty-starter'); ?>"><?php echo esc_html($single_feature_list['sassty_feature_title'], 'sassty-starter'); ?></a></h4>
                  <p class="mb-0"><?php echo sassty_starter_kses($single_feature_list['sassty_feature_description'], 'sassty-starter'); ?></p>
               </div>
            </div>
         <?php endforeach; endif;?>
      </div>
   </div>
</div>
<!-- feature-area-end -->



<!-- testimonial-area-start -->
<div class="it-testimonial-area p-relative pt-115 pb-120">
   <img class="it-testimonial-shape-4" src="<?php echo esc_url($testimonial_thumbnail_shape4, 'sassty-starter'); ?>" alt="">
   <div class="container">
      <div class="row align-items-center">
         <div class="col-xl-5 col-lg-5 order-1 order-xl-0">
            <div class="d-block text-center text-lg-start">
               <div class="it-testimonial-left-box text-xl-start d-inline-block text-center  p-relative">
                  <img class="it-testimonial-shape-1 d-none d-sm-block" src="<?php echo esc_url($testimonial_thumbnail_shape, 'sassty-starter'); ?>" alt="">
                  <img class="it-testimonial-shape-2 d-none d-xl-block" src="<?php echo esc_url($testimonial_thumbnail_shape2, 'sassty-starter'); ?>" alt="">
                  <img class="it-testimonial-shape-3 d-none d-xl-block" src="<?php echo esc_url($testimonial_thumbnail_shape3, 'sassty-starter'); ?>" alt="">
                  <div class="it-testimonial-thumb">
                     <img src="<?php echo esc_url($testimonial_thumbnail_image, 'sassty-starter'); ?>" alt="">
                  </div>
               </div>
            </div>
         </div>
         <div class="col-xl-7 col-lg-7 order-0 order-lg-1">
            <div class="it-testimonial-right-box p-relative">
               <div class="it-section-title-box it-text-anim mb-65">
                  <h4 class="it-section-title mb-15 it-split-text it-split-in-right"><?php echo sassty_starter_kses($sassty_starter_testi_section_title, 'sassty-starter'); ?></h4>
                  <p><?php echo sassty_starter_kses($sassty_starter_testi_section_desc, 'sassty-starter'); ?></p>
               </div>
               <div class="it-testimonial-arrow-box d-none d-lg-block">
                  <button class="slider-next active">
                     <span>
                        <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M25.5303 5.46967C25.8232 5.76256 25.8232 6.23743 25.5303 6.53033L20.7574 11.3033C20.4645 11.5962 19.9896 11.5962 19.6967 11.3033C19.4038 11.0104 19.4038 10.5355 19.6967 10.2426L23.9393 6L19.6967 1.75736C19.4038 1.46446 19.4038 0.989591 19.6967 0.696697C19.9896 0.403804 20.4645 0.403804 20.7574 0.696697L25.5303 5.46967ZM-6.55672e-08 5.25L25 5.25L25 6.75L6.55672e-08 6.75L-6.55672e-08 5.25Z" fill="currentcolor" />
                        </svg>
                     </span>
                  </button>
                  <button class="slider-prev">
                     <span>
                        <svg width="26" height="12" viewBox="0 0 26 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                           <path d="M0.469669 5.46967C0.176777 5.76256 0.176777 6.23743 0.469669 6.53033L5.24264 11.3033C5.53553 11.5962 6.01041 11.5962 6.3033 11.3033C6.59619 11.0104 6.59619 10.5355 6.3033 10.2426L2.06066 6L6.3033 1.75736C6.59619 1.46446 6.59619 0.989591 6.3033 0.696697C6.01041 0.403804 5.53553 0.403804 5.24264 0.696697L0.469669 5.46967ZM26 5.25L1 5.25L1 6.75L26 6.75L26 5.25Z" fill="currentcolor" />
                        </svg>
                     </span>
                  </button>
               </div>
               <div class="swiper-container it-testimonial-active">
                  <div class="swiper-wrapper d-flex align-items-center">
                     <?php 
                     if (!empty($sassty_starter_testimonial_list) && is_array($sassty_starter_testimonial_list)): 
                     foreach ($sassty_starter_testimonial_list as $single_testimonial_list):
                      ?>
                        <div class="swiper-slide">
                           <div class="it-testimonial-item">
                              <span class="it-testimonial-quote mb-25">
                                 <svg width="26" height="21" viewBox="0 0 26 21" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M9.92382 4.12377H10.4125V0H9.92382C7.29263 0.00362133 4.77028 1.05059 2.90993 2.91131C1.04958 4.77203 0.00310307 7.29459 0 9.92577V20.785H11.347V9.43706H4.14136C4.26583 7.98861 4.92872 6.63943 5.99922 5.65579C7.06971 4.67216 8.47003 4.12552 9.92382 4.12377ZM10.3695 10.4155V19.8085H0.977427V9.92577C0.980109 7.63795 1.85793 5.43784 3.4309 3.77654C5.00387 2.11525 7.15279 1.11865 9.43706 0.991111V3.16002C7.72867 3.28532 6.1308 4.05187 4.96393 5.30594C3.79705 6.56002 3.14743 8.20888 3.14536 9.92186V10.4106L10.3695 10.4155Z" fill="#01103D" />
                                    <path d="M18.7976 9.43706C18.9218 7.98844 19.5846 6.63902 20.6552 5.65518C21.7257 4.67134 23.1261 4.12456 24.5801 4.12279H25.0688V0H24.5801C21.9485 0.00284596 19.4255 1.04951 17.5646 2.91033C15.7038 4.77116 14.6571 7.29417 14.6543 9.92577V20.785H26.0003V9.43706H18.7976ZM25.0228 19.8085H15.6298V9.92577C15.6324 7.63811 16.5101 5.43813 18.0829 3.77686C19.6556 2.11559 21.8043 1.1189 24.0884 0.991111V3.16002C22.38 3.28532 20.7822 4.05187 19.6153 5.30594C18.4484 6.56002 17.7988 8.20888 17.7967 9.92186V10.4106H25.0228V19.8085Z" fill="#01103D" />
                                 </svg>
                              </span>
                              <div class="it-testimonial-ratting mb-30">
                                 <span>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M20 7.72742L12.7329 7.24965L9.99602 0.374023L7.25918 7.24965L0 7.72742L5.56773 12.455L3.7407 19.6264L9.99602 15.6725L16.2514 19.6264L14.4243 12.455L20 7.72742Z" fill="#F59E0B" />
                                    </svg>
                                 </span>
                                 <span>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M20 7.72742L12.7329 7.24965L9.99602 0.374023L7.25918 7.24965L0 7.72742L5.56773 12.455L3.7407 19.6264L9.99602 15.6725L16.2514 19.6264L14.4243 12.455L20 7.72742Z" fill="#F59E0B" />
                                    </svg>
                                 </span>
                                 <span>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M20 7.72742L12.7329 7.24965L9.99602 0.374023L7.25918 7.24965L0 7.72742L5.56773 12.455L3.7407 19.6264L9.99602 15.6725L16.2514 19.6264L14.4243 12.455L20 7.72742Z" fill="#F59E0B" />
                                    </svg>
                                 </span>
                                 <span>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M20 7.72742L12.7329 7.24965L9.99602 0.374023L7.25918 7.24965L0 7.72742L5.56773 12.455L3.7407 19.6264L9.99602 15.6725L16.2514 19.6264L14.4243 12.455L20 7.72742Z" fill="#F59E0B" />
                                    </svg>
                                 </span>
                                 <span>
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                       <path d="M20 7.72742L12.7329 7.24965L9.99602 0.374023L7.25918 7.24965L0 7.72742L5.56773 12.455L3.7407 19.6264L9.99602 15.6725L16.2514 19.6264L14.4243 12.455L20 7.72742Z" fill="#F59E0B" />
                                    </svg>
                                 </span>
                              </div>
                              <p class="it-testimonial-text"><?php echo esc_html($single_testimonial_list['sassty_testi_description'], 'sassty-starter'); ?></p>
                              <div class="it-testimonial-author-wrap d-flex align-items-center justify-content-between">
                                 <div class="it-testimonial-author-info">
                                    <h5><?php echo esc_html($single_testimonial_list['sassty_testi_title'], 'sassty-starter'); ?></h5>
                                    <span><?php echo esc_html($single_testimonial_list['sassty_testi_desigantion'], 'sassty-starter'); ?></span>
                                 </div>
                                 <img src="<?php echo esc_url($single_testimonial_list['sassty_testi_image'], 'sassty-starter'); ?>" alt="">
                              </div>
                           </div>
                        </div>
                     <?php endforeach; endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- testimonial-area-end -->

<!-- blog-area-start -->
<div class="it-blog-area it-blog-mlr">
   <div class="it-blog-wrap">
      <div class="container">
         <div class="row">
            <div class="col-xl-12">
               <div class="it-section-title-box text-center it-text-anim mb-55">
                  <h4 class="it-section-title it-split-text it-split-in-right mb-15"><?php echo sassty_starter_kses($sassty_starter_blog_section_title, 'sassty-starter'); ?></h4>
                  <p><?php echo sassty_starter_kses($sassty_starter_blog_section_description, 'sassty-starter'); ?></p>
               </div>
            </div>
         </div>
         <div class="row">


            <?php
            // Arguments for WP_Query
            $args = array(
               'post_type'      => 'post', // Retrieves blog posts
               'posts_per_page' => 3,      // Number of posts to display
               'order'          => 'DESC', // Display newest posts first
               'orderby'        => 'rand'  // Order by date
            );

            // The Query
            $query = new WP_Query($args);

            // The Loop
            if ($query->have_posts()) :
               while ($query->have_posts()) : $query->the_post(); ?>
                  <div class="col-xl-4 col-lg-6 col-md-6 it-fade-anim" data-fade-from="bottom" data-delay=".3">
                     <div class="it-blog-item zoom white-bg mb-30">
                        <div class="it-blog-thumb img-zoom">
                           <a href="<?php the_permalink(); ?>">
                              <?php if (has_post_thumbnail()) : ?>
                                 <?php the_post_thumbnail('full', array('class' => 'w-100')); ?>
                            
                              <?php endif; ?>
                           </a>
                        </div>
                        <div class="it-blog-content">
                           <div class="it-blog-meta mb-25">
                              <span><?php echo get_the_date('F d, Y'); ?></span>
                              <?php
                              // Retrieve the first category
                              $categories = get_the_category();
                              if (!empty($categories)) :
                                 echo '<i>' . esc_html($categories[0]->name) . '</i>';
                              endif;
                              ?>
                           </div>
                           <h4 class="it-blog-title mb-20">
                              <a class="border-line-theme title-hover" href="<?php the_permalink(); ?>">
                                 <?php the_title(); ?>
                              </a>
                           </h4>
                           <p>
                              <?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?>
                           </p>
                           <a class="it-blog-link border-line-theme title-hover" href="<?php the_permalink(); ?>">
                              Read More
                              <svg width="21" height="12" viewBox="0 0 21 12" fill="none" xmlns="http://www.w3.org/2000/svg">
                                 <path d="M20.5303 6.53033C20.8232 6.23744 20.8232 5.76256 20.5303 5.46967L15.7574 0.696699C15.4645 0.403806 14.9896 0.403806 14.6967 0.696699C14.4038 0.989593 14.4038 1.46447 14.6967 1.75736L18.9393 6L14.6967 10.2426C14.4038 10.5355 14.4038 11.0104 14.6967 11.3033C14.9896 11.5962 15.4645 11.5962 15.7574 11.3033L20.5303 6.53033ZM0 6.75H20V5.25H0V6.75Z" fill="currentcolor" />
                              </svg>
                           </a>
                        </div>
                     </div>

                  </div>
            <?php endwhile;
               wp_reset_postdata();
            else :
               echo '<p>No posts found.</p>';
            endif;
            ?>



         </div>
         <?php if (!empty($sassty_starter_blog_section_button_text)): ?>
            <div class="row">
               <div class="col-12">
                  <div class="it-blog-button text-center mt-30 it-fade-anim" data-fade-from="top" data-ease="bounce" data-delay=".5">
                     <a class="it-btn" href="<?php echo esc_url($sassty_starter_blog_section_button_link, 'sassty-starter'); ?>"><?php echo esc_html($sassty_starter_blog_section_button_text, 'sassty-starter'); ?></a>
                  </div>
               </div>
            </div>

         <?php endif; ?>
      </div>
   </div>
</div>
<!-- blog-area-end -->


<?php get_footer(); ?>
<?php

/**
 * Template part for displaying header side information
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package sassty_starter
 */

$side_info_title = get_theme_mod('side_info_title', __('Get In Touch', 'sassty-starter'));
$side_info_social_switcher = get_theme_mod('side_info_social_switcher', 'sassty-starter');
$side_info_email = get_theme_mod('side_info_email', __('info@sassty_starter.com', 'sassty-starter'));
$side_info_phone = get_theme_mod('side_info_phone', __('(00)5611227890', 'sassty-starter'));
$side_info_location = get_theme_mod('side_info_location', __('238, Arimantab, Moska - USA.', 'sassty-starter'));
$side_info_location_url = get_theme_mod('side_info_location_url', __('htits://www.google.com/maps/@37.4801311,22.8928877,3z', 'sassty-starter'));
$header_side_logo = get_theme_mod('header_side_logo', 'sassty-starter');
$side_info_twitter_url = get_theme_mod('side_info_twitter_url', 'sassty-starter');
$side_info_instagram_url = get_theme_mod('side_info_instagram_url', 'sassty-starter');
$side_info_facebook_url = get_theme_mod('side_info_facebook_url', 'sassty-starter');
$side_info_dribbble_url = get_theme_mod('side_info_dribbble_url', 'sassty-starter');

?>
<!-- it-offcanvus-area-start -->
<div class="it-offcanvas-area">
   <div class="itoffcanvas">
      <div class="it-offcanva-bottom-shape d-none d-xxl-block">
      </div>
      <div class="itoffcanvas__close-btn">
         <button class="close-btn"><i class="fal fa-times"></i></button>
      </div>
      <div class="itoffcanvas__logo">

         <!--show header custom logo or site blog info -->
         <?php if (has_custom_logo()) : ?>
            <div class="it-header-logo-img">
               <?php the_custom_logo(); ?>
            </div>
         <?php else : ?>
            <h2 class="it-header-logo-text">
               <a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a>
            </h2>
         <?php endif; ?>

      </div>
      <div class="it-menu-mobile d-xl-none"></div>
      <div class="itoffcanvas__info">
         <h3 class="offcanva-title"><?php echo esc_html($side_info_title, 'sassty-starter'); ?></h3>
         <?php if (!empty($side_info_email)): ?>
            <div class="it-info-wrapper mb-20 d-flex align-items-center">
               <div class="itoffcanvas__info-icon">
                  <a href="#"><i class="fal fa-envelope"></i></a>
               </div>
               <div class="itoffcanvas__info-address">
                  <span><?php echo esc_html__('Email', 'sassty-starter'); ?></span>
                  <a href="maito:<?php echo esc_attr($side_info_email, 'sassty-starter'); ?>"><?php echo esc_html($side_info_email, 'sassty-starter'); ?></a>
               </div>
            </div>
         <?php endif; ?>

         <?php if (!empty($side_info_phone)): ?>
            <div class="it-info-wrapper mb-20 d-flex align-items-center">
               <div class="itoffcanvas__info-icon">
                  <a href="#"><i class="fal fa-phone-alt"></i></a>
               </div>
               <div class="itoffcanvas__info-address">
                  <span><?php echo esc_html__('Phone', 'sassty-starter'); ?></span>
                  <a href="tel:(00)45611227890"><?php echo esc_html($side_info_phone, 'sassty-starter'); ?></a>
               </div>
            </div>
         <?php endif; ?>
         <?php if (!empty($side_info_location)): ?>
            <div class="it-info-wrapper mb-20 d-flex align-items-center">
               <div class="itoffcanvas__info-icon">
                  <a href="#"><i class="fas fa-map-marker-alt"></i></a>
               </div>
               <div class="itoffcanvas__info-address">
                  <span><?php echo esc_html__('Location', 'sassty-starter'); ?></span>
                  <a href="<?php echo esc_attr($side_info_location_url); ?>" target="_blank"><?php echo esc_html($side_info_location, 'sassty-starter'); ?></a>
               </div>
            </div>
         <?php endif; ?>
      </div>
      <?php if (!empty($side_info_social_switcher)): ?>
         <div class="itoffcanvas__social">
            <div class="social-icon">
               <?php if (!empty($side_info_twitter_url)): ?>
                  <a href="<?php echo esc_url($side_info_twitter_url, 'sassty-starter'); ?>"><i class="fab fa-twitter"></i></a>
               <?php endif; ?>
               <?php if (!empty($side_info_instagram_url)): ?>
                  <a href="<?php echo esc_url($side_info_instagram_url, 'sassty-starter'); ?>"><i class="fab fa-instagram"></i></a>
               <?php endif; ?>
               <?php if (!empty($side_info_facebook_url)): ?>
                  <a href="<?php echo esc_url($side_info_facebook_url, 'sassty-starter'); ?>"><i class="fab fa-facebook-square"></i></a>
               <?php endif; ?>
               <?php if (!empty($side_info_dribbble_url)): ?>
                  <a href="<?php echo esc_url($side_info_dribbble_url, 'sassty-starter'); ?>"><i class="fab fa-dribbble"></i></a>
               <?php endif; ?>
            </div>
         </div>
      <?php endif; ?>
   </div>
</div>
<div class="body-overlay"></div>
<!-- it-offcanvus-area-end -->
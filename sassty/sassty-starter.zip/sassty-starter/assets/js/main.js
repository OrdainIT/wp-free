(function ($) {
  ("use strict");

  var windowOn = $(window);
  ///////////////////////////////////////////////////
  // 01. PreLoader Js
  windowOn.on("load", function () {
    $("#preloader").fadeOut(500);
  });

  ///////////////////////////////////////////////////
  // 07. Sticky Header Js
  windowOn.on("scroll", function () {
    var scroll = windowOn.scrollTop();
    if (scroll < 400) {
      $("#header-sticky").removeClass("header-sticky");
    } else {
      $("#header-sticky").addClass("header-sticky");
    }
  });

  //One Page Scroll Js
  function scrollNav() {
    $(".it-onepage-menu a").click(function () {
      $(".it-onepage-menu a.active").removeClass("active");
      $(this).addClass("active");

      $("html, body")
        .stop()
        .animate(
          {
            scrollTop: $($(this).attr("href")).offset().top - 80,
          },
          300
        );
      return false;
    });
  }
  scrollNav();











  if ($(".it-menu-content").length && $(".it-menu-mobile").length) {
    let navContent = document.querySelector(".it-menu-content").outerHTML;
    let mobileNavContainer = document.querySelector(".it-menu-mobile");
    mobileNavContainer.innerHTML = navContent;

    let arrow = $(".it-menu-mobile .has-dropdown > a");

    arrow.each(function () {
      let self = $(this);
      let arrowBtn = document.createElement("BUTTON");
      arrowBtn.classList.add("dropdown-toggle-btn");
      arrowBtn.innerHTML = "<i class='fal fa-angle-right'></i>";
      self.append(function () {
        return arrowBtn;
      });

      self.find("button").on("click", function (e) {
        e.preventDefault();
        let self = $(this);
        self.toggleClass("dropdown-opened");
        self.parent().toggleClass("expanded");
        self
          .parent()
          .parent()
          .addClass("dropdown-opened")
          .siblings()
          .removeClass("dropdown-opened");
        self.parent().parent().children(".it-submenu").slideToggle();
      });
    });
  }

  ///////////////////////////////////////////////////
  // 03. scroll-to-target
  windowOn.on("scroll", function () {
    var scroll = windowOn.scrollTop();
    if (scroll < 500) {
      $(".scroll-to-target").removeClass("open");
    } else {
      $(".scroll-to-target").addClass("open");
    }
  });

  ///////////////////////////////////////////////////
  // 04. Scroll Up Js
  if ($(".scroll-to-target").length) {
    $(".scroll-to-target").on("click", function () {
      var target = $(this).attr("data-target");
      // animate
      $("html, body").animate(
        {
          scrollTop: $(target).offset().top,
        },
        1000
      );
    });
  }

  ////////////////////////////////////////////////////
  // 09. Sidebar Js
  $(".it-menu-bar").on("click", function () {
    $(".itoffcanvas").addClass("opened");
    $(".body-overlay").addClass("apply");
  });
  $(".close-btn").on("click", function () {
    $(".itoffcanvas").removeClass("opened");
    $(".body-overlay").removeClass("apply");
  });
  $(".body-overlay").on("click", function () {
    $(".itoffcanvas").removeClass("opened");
    $(".body-overlay").removeClass("apply");
  });

  ////////////////////////////////////////////////////
  // 03. Search Js
  $(".search-open-btn").on("click", function () {
    $(".search__popup").addClass("search-opened");
  });

  $(".search-close-btn").on("click", function () {
    $(".search__popup").removeClass("search-opened");
  });





 



})(jQuery);

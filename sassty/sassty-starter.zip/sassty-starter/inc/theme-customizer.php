<?php

/**
 * sassty_starter customizer
 *
 * @package sassty_starter
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}


add_action(
    'init',
    function () {

        if (class_exists('kirki')) {

            /**
             * Added Panels & Sections
             */

            //Add panel
            new \Kirki\Panel(
                'sassty_starter_customizer',
                [
                    'priority'    => 10,
                    'title'       => esc_html__('Saasty Customizer', 'sassty-starter'),
                ]
            );


               //Add panel
            new \Kirki\Panel(
                'sassty_starter_front_page',
                [
                    'priority'    => 10,
                    'title'       => esc_html__('Front Page', 'sassty-starter'),
                ]
            );


             /**
             * Front Page
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_hero_section',
                [
                    'title'       => esc_html__('Hero Section', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'panel'       => 'sassty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_hero_title',
                    'label'       => esc_html__( 'Title', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => sassty_starter_kses('Successful Businesses Begin with Organized Finances.', 'sassty-starter' ),
                ]
            );

            // sub title

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_hero_subtitle',
                    'label'       => esc_html__( 'Sub Title', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => sassty_starter_kses('Welcome Our SaasTech', 'sassty-starter' ),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_hero_desc',
                    'label'       => esc_html__( 'Description', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => sassty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'sassty-starter' ),
                ]
            );

            // button text

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_hero_btn_text',
                    'label'       => esc_html__( 'Button Text', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => sassty_starter_kses( 'Get Started', 'sassty-starter' ),
                ]
            );

            // button link

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_hero_btn_link',
                    'label'       => esc_html__( 'Button Link', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => sassty_starter_kses( '#', 'sassty-starter' ),
                ]
            );


            // thumbnail

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_hero_image',
                    'label'       => esc_html__( 'Hero Image', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/hero-1.png',
                ]
            );

            // Shape

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_hero_shape',
                    'label'       => esc_html__( 'Hero Shape', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-1.png',
                ]
            );

            // shape 2

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_hero_shape_2',
                    'label'       => esc_html__( 'Hero Shape 2', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-2.png',
                ]
            );

            // shape 3

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_hero_shape_3',
                    'label'       => esc_html__( 'Hero Shape 3', 'sassty-starter' ),
                    'section'     => 'sassty_starter_hero_section',
                    'default'     => get_template_directory_uri() . '/assets/img/hero/shape-3.png',
                ]
            );

            /**
             * Feature Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_about_section',
                [
                    'title'       => esc_html__('About Section', 'sassty-starter'),
                    'panel'       => 'sassty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            // about title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_about_title',
                    'label'       => esc_html__( 'Title', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => sassty_starter_kses('About Us', 'sassty-starter' ),
                ]
            );

            // about description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_about_desc',
                    'label'       => esc_html__( 'Description', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => sassty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'sassty-starter' ),
                ]
            );

            new \Kirki\Field\Repeater(
                [
                    'settings' => 'sassty_about_faqs',
                    'label'    => esc_html__('About FAQ', 'sassty-starter'),
                    'section'  => 'sassty_starter_about_section',
                    'priority' => 10,
                    'fields'   => [
                        'sassty_about_faq_title'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('Title', 'sassty-starter'),
                            'description' => esc_html__('Title', 'sassty-starter'),
                            'default'     => '',
                        ],
                        'sassty_about_faq_description'   => [
                            'type'        => 'textarea',
                            'label'       => esc_html__('Description', 'sassty-starter'),
                            'description' => esc_html__('Description', 'sassty-starter'),
                            'default'     => '',
                        ],
                    ],
                ]
            );

            // about thumbnail

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_about_image',
                    'label'       => esc_html__( 'About Image', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-1.png',
                ]
            );

            // about thumbnial 2

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_about_image_2',
                    'label'       => esc_html__( 'About Image 2', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-2.png',
                ]
            );

            // about thumbnial 3

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_about_image_3',
                    'label'       => esc_html__( 'About Image 3', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/about-3.png',
                ]
            );

            // shape

            new \Kirki\Field\Image(
                [
                    'settings'    => 'sassty_starter_about_shape',
                    'label'       => esc_html__( 'About Shape', 'sassty-starter' ),
                    'section'     => 'sassty_starter_about_section',
                    'default'     => get_template_directory_uri() . '/assets/img/about/shape-1.png',
                ]
            );




            /**
             * Feature Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_feature_section',
                [
                    'title'       => esc_html__('Feature Section', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'panel'       => 'sassty_starter_front_page',
                    'priority'    => 10,
                ]
            );


            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_feature_title',
                    'label'       => esc_html__( 'Title', 'sassty-starter' ),
                    'section'     => 'sassty_starter_feature_section',
                    'default'     => sassty_starter_kses('Our Features', 'sassty-starter' ),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_feature_desc',
                    'label'       => esc_html__( 'Description', 'sassty-starter' ),
                    'section'     => 'sassty_starter_feature_section',
                    'default'     => sassty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'sassty-starter' ),
                ]
            );


            new \Kirki\Field\Repeater(
                [
                    'settings' => 'sassty_starter_feature_list',
                    'label'    => esc_html__('Feature List', 'sassty-starter'),
                    'section'  => 'sassty_starter_feature_section',
                    'priority' => 10,
                    'default'  => [
                        [
                            'sassty_feature_title'   => esc_html__('Title', 'sassty-starter'),
                            'default' => esc_html__('Title', 'sassty-starter'),
                        ],
                        [
                            'sassty_feature_title'   => esc_html__('Title', 'sassty-starter'),
                            'default' => esc_html__('Title', 'sassty-starter'),
                        ],
                    ],
                    'fields'   => [
                        'sassty_feature_title'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('Title', 'sassty-starter'),
                            'description' => esc_html__('Title', 'sassty-starter'),
                            'default'     => '',
                        ],
                        'sassty_feature_description'    => [
                            'type'        => 'textarea',
                            'label'       => esc_html__('Description', 'sassty-starter'),
                            'description' => esc_html__('Description', 'sassty-starter'),
                            'default'     => '',
                        ],
                        
                        'sassty_feature_image'    => [
                            'type'        => 'image',
                            'label'       => esc_html__('Feature Image', 'sassty-starter'),
                            'default'     => '',
                        ],
                        'sassty_feature_url'   => [
                            'type'        => 'text',
                            'label'       => esc_html__('URL', 'sassty-starter'),
                            'description' => esc_html__('#', 'sassty-starter'),
                            'default'     => '',
                        ],


                    ],
                ]
            );


            /**
             * Testimonial Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_testimonial_section',
                [
                    'title'       => esc_html__('Testimonial Section', 'sassty-starter'),
                    'panel'       => 'sassty_starter_front_page',
                    'priority'    => 10,
                ]
            );



            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_testi_section_title',
                    'label'       => esc_html__('Title', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => sassty_starter_kses('What our clients say?', 'sassty-starter'),
                ]
            );

            // description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_testi_section_desc',
                    'label'       => esc_html__('Description', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => sassty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'sassty-starter'),
                ]
            );



            new \Kirki\Field\Repeater(
                    [
                        'settings' => 'sassty_starter_testimonial_list',
                        'label'    => esc_html__('Testimonial List', 'sassty-starter'),
                        'section'  => 'sassty_starter_testimonial_section',
                        'priority' => 10,
                        'fields'   => [
                            'sassty_testi_title'   => [
                                'type'        => 'text',
                                'label'       => esc_html__('Name', 'sassty-starter'),
                                'description' => esc_html__('Name', 'sassty-starter'),
                                'default'     => '',
                            ],
                            'sassty_testi_desigantion' => [
                                'type'        => 'text',
                                'label'       => esc_html__('Designation', 'sassty-starter'),
                                'description' => esc_html__('Description', 'sassty-starter'),
                                'default'     => '',
                            ],
                            'sassty_testi_description' => [
                                'type'        => 'textarea',
                                'label'       => esc_html__('Description', 'sassty-starter'),
                                'description' => esc_html__('Description', 'sassty-starter'),
                                'default'     => '',
                            ],
                            'sassty_testi_image' => [
                                'type'        => 'image',
                                'label'       => esc_html__('Image', 'sassty-starter'),
                                'description' => esc_html__('Image', 'sassty-starter'),
                                'default'     => '',
                            ],
                        ],
                    ]
                );


            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_image',
                    'label'       => esc_html__('Thumbnail', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => '',
                ]
            );


            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape',
                    'label'       => esc_html__('Shap 1', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => '',
                ]
            );
            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape2',
                    'label'       => esc_html__('Shap 2', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => '',
                ]
            );

            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape3',
                    'label'       => esc_html__('Shap 3', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => '',
                ]
            );
            new \Kirki\Field\Image(
                [
                    'settings'    => 'testimonial_thumbnail_shape4',
                    'label'       => esc_html__('Shap 4', 'sassty-starter'),
                    'section'     => 'sassty_starter_testimonial_section',
                    'default'     => '',
                ]
            );



            /**
             * Testimonial Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_Blog_section',
                [
                    'title'       => esc_html__('Blog Section', 'sassty-starter'),
                    'panel'       => 'sassty_starter_front_page',
                    'priority'    => 10,
                ]
            );

            // blog Section title

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_blog_section_title',
                    'label'       => esc_html__('Title', 'sassty-starter'),
                    'section'     => 'sassty_starter_Blog_section',
                    'default'     => sassty_starter_kses('Our Blog', 'sassty-starter'),
                ]
            );

            // blog Section description

            new \Kirki\Field\Textarea(
                [
                    'settings'    => 'sassty_starter_blog_section_desc',
                    'label'       => esc_html__('Description', 'sassty-starter'),
                    'section'     => 'sassty_starter_Blog_section',
                    'default'     => sassty_starter_kses('Efficient planning, seamless collaboration, and top-notch <br> data protection – all in one place.', 'sassty-starter'),
                ]
            );

            // blog Section button text

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_blog_section_btn_text',
                    'label'       => esc_html__('Button Text', 'sassty-starter'),
                    'section'     => 'sassty_starter_Blog_section',
                    'default'     => sassty_starter_kses('View All', 'sassty-starter'),
                ]
            );

            // blog Section button link

            new \Kirki\Field\Text(
                [
                    'settings'    => 'sassty_starter_blog_section_btn_link',
                    'label'       => esc_html__('Button Link', 'sassty-starter'),
                    'section'     => 'sassty_starter_Blog_section',
                    'default'     => sassty_starter_kses('#', 'sassty-starter'),
                ]
            );





           

       






            /**
             * Customizer Section
             */
            //=========== General Settings ================ //
            new \Kirki\Section(
                'sassty_starter_general_settngs',
                [
                    'title'       => esc_html__('General Settings', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'panel'       => 'sassty_starter_customizer',
                    'priority'    => 10,
                ]
            );



            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'sassty_starter_preloader',
                    'label'       => esc_html__('Preloader On/Off', 'sassty-starter'),
                    'section'     => 'sassty_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'sassty-starter'),
                        'off' => esc_html__('Disable', 'sassty-starter'),
                    ],
                ]
            );

            new \Kirki\Field\Checkbox_Switch(
                [
                    'settings'    => 'sassty_starter_backtotop',
                    'label'       => esc_html__('Back To Top On/Off', 'sassty-starter'),
                    'section'     => 'sassty_starter_general_settngs',
                    'default'     => 'off',
                    'choices'     => [
                        'on'  => esc_html__('Enable', 'sassty-starter'),
                        'off' => esc_html__('Disable', 'sassty-starter'),
                    ],
                ]
            );










            


      

           

        



            // Header Logo & Style Settings
            new \Kirki\Section(
                'sassty_starter_header_logo',
                [
                    'title'       => esc_html__('Header Settings', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'panel'       => 'sassty_starter_customizer',
                    'priority'    => 10,
                ]
            );

            new \Kirki\Field\Select(
                [
                    'settings'    => 'sassty_starter_header_style',
                    'label'       => esc_html__('Select Header Style', 'sassty-starter'),
                    'section'     => 'sassty_starter_header_logo',
                    'default'     => 'header-style-11',
                    'placeholder' => esc_html__('Choose an option', 'sassty-starter'),
                    'choices'     => [
                        'header-style-11' => esc_html__('Header Style 1', 'sassty-starter'),
                    ],
                ]
            );


            //Header Logo
            new \Kirki\Field\Image(
                [
                    'settings'    => 'header_logo',
                    'label'       => esc_html__('Header Logo', 'sassty-starter'),
                    'description' => esc_html__('Upload Your Logo Here', 'sassty-starter'),
                    'section'     => 'sassty_starter_header_logo',
                    'default'     => get_template_directory_uri() . '/assets/img/logo/logo-1.png',
                ]
            );











            


            //Blog Settings
            new \Kirki\Section(
                'sassty_starter_404_settings',
                [
                    'title'       => esc_html__('404 Settings', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'panel'       => 'sassty_starter_customizer',
                    'priority'    => 10,
                ]
            );

            new \Kirki\Field\Image(
                [
                    'settings'    => '_image_404_setup',
                    'label'       => esc_html__('Upload 404 Image', 'sassty-starter'),
                    'description' => esc_html__('', 'sassty-starter'),
                    'section'     => 'sassty_starter_404_settings',
                    'default'     => get_template_directory_uri() . '/assets/img/error/error.png',
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'sassty_starter_error_title',
                    'label'    => esc_html__('Title ', 'sassty-starter'),
                    'section'  => 'sassty_starter_404_settings',
                    'default'  => sassty_starter_kses('Oops! That page can’t be found.', 'sassty-starter'),
                    'priority' => 10,
                ]
            );

            new \Kirki\Field\Text(
                [
                    'settings' => 'sassty_starter_error_desc',
                    'label'    => esc_html__('Description ', 'sassty-starter'),
                    'section'  => 'sassty_starter_404_settings',
                    'default'  => sassty_starter_kses('Oops! The page you are looking for does not exist. It might have <br> been moved or deleted. Please check and try again.', 'sassty-starter'),
                    'priority' => 10,
                ]
            );
            new \Kirki\Field\Text(
                [
                    'settings' => 'sassty_starter_error_link_text',
                    'label'    => esc_html__('Button Text', 'sassty-starter'),
                    'section'  => 'sassty_starter_404_settings',
                    'default'  => esc_html__('Back to Home', 'sassty-starter'),
                    'priority' => 10,
                ]
            );

            
}







    }
);
